import { readfile } from 'fs';
let j = json(readfile('/etc/vless-manager/singbox.json'));
let rt = j.route || {};
for (let r in (rt.rules || [])) {
    let parts = [];
    for (let k in r) {
        if (k == 'outbound') continue;
        let v = r[k];
        push(parts, k + ':' + (type(v) == 'array' ? join(',', v) : v));
    }
    print('rule=' + join(' ', parts) + '|' + r.outbound + '\n');
}
print('final=' + (rt.final || '') + '\n');
