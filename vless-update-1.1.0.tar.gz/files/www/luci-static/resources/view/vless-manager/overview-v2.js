'use strict';
'require view';
'require fs';
'require ui';

var command = '/usr/libexec/vless-manager';

function execute(args) {
    return fs.exec(command, args).then(function(r) {
        if (r.code !== 0) throw new Error((r.stdout || r.stderr || 'Operation failed').trim());
        return (r.stdout || '').trim();
    });
}

var NS = {};
function latencyCell(name) {
    var s = NS[name];
    if (!s) return E('span', {}, '-');
    if (s.st === 'DOWN') return E('span', { 'style': 'color:#ff5555;font-weight:bold;' }, 'Down');
    var c = s.ms < 150 ? '#00e676' : (s.ms < 400 ? '#ffd600' : '#ff5555');
    return E('span', { 'style': 'color:' + c + ';font-weight:bold;' }, s.ms + ' ms' + (s.st === 'ACTIVE' ? ' (penuh)' : ''));
}

return view.extend({
    load: function() {
        return Promise.all([
            execute(['list']).then(function(s) { return JSON.parse(s); }),
            execute(['status']).catch(function() { return 'STOPPED'; }),
            execute(['global_status']).catch(function() { return 'OFF'; }),
            execute(['node_status']).catch(function() { return ''; })
        ]);
    },
    render: function(data) {
        var nodesData = data[0];
        var isRunning = (data[1] === 'RUNNING');
        var isGlobalOn = (data[2] === 'ON');
            String(data[3] === undefined ? '' : data[3]).split('\n').forEach(function(l) { var p = l.split('|'); if (p.length === 3) NS[p[0]] = { st: p[1], ms: parseInt(p[2], 10) }; });

        // --- CSS TEMA GEOMETRIK (Versi Padat & Kecil) ---
        var style = E('style', {}, `
            .v-dash { 
                background-color: #2b0147;
                background-image: 
                    radial-gradient(circle at 10% 25%, #ff007f 0%, #ff007f 2%, transparent 2.5%),
                    radial-gradient(circle at 85% 75%, #3d5afe 0%, #3d5afe 3%, transparent 3.5%),
                    linear-gradient(115deg, transparent 20%, rgba(255, 235, 59, 0.9) 20.2%, rgba(255, 235, 59, 0.9) 20.8%, transparent 21%),
                    linear-gradient(115deg, transparent 75%, rgba(255, 109, 0, 0.9) 75.2%, rgba(255, 109, 0, 0.9) 76.2%, transparent 76.4%),
                    linear-gradient(135deg, transparent 40%, rgba(255, 255, 255, 0.5) 40.2%, rgba(255, 255, 255, 0.5) 40.6%, transparent 40.8%),
                    linear-gradient(145deg, #1b0044 0%, #9c005b 45%, #d6004f 75%, #3a005c 100%);
                padding: 16px 10px; 
                border-radius: 16px; 
                box-shadow: 0 10px 30px rgba(0,0,0,0.5);
            }
            
            .v-card { 
                background: rgba(15, 10, 30, 0.65); 
                backdrop-filter: blur(12px); 
                -webkit-backdrop-filter: blur(12px);
                border: 1px solid rgba(255, 255, 255, 0.15); 
                border-radius: 12px; 
                padding: 14px 12px; 
                margin-bottom: 16px; 
                box-shadow: 0 8px 24px rgba(0, 0, 0, 0.3); 
            }
            
            .v-card-title { 
                font-family: 'Georgia', serif; 
                font-size: 1.1em; 
                font-weight: bold; 
                color: #ffeb3b; 
                margin-bottom: 12px; 
                padding-bottom: 6px; 
                border-bottom: 2px dashed rgba(255, 235, 59, 0.3); 
                text-shadow: 0 0 8px rgba(255, 235, 59, 0.4);
            }
            
            .status-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 10px; }
            
            .status-box { 
                background: rgba(0, 0, 0, 0.4); 
                border-radius: 10px; 
                padding: 12px 8px; 
                text-align: center; 
                border: 1px solid rgba(255, 255, 255, 0.1); 
                display: flex; flex-direction: column; align-items: center; 
            }
            
            .status-box h4 { font-family: 'Tahoma', sans-serif; font-size: 0.8em; font-weight: bold; color: #ffffff; margin: 0 0 10px 0; }
            .badge { padding: 4px 10px; border-radius: 20px; font-size: 0.7em; font-weight: bold; margin-bottom: 12px; font-family: 'Arial', sans-serif; }
            .bg-green { background: rgba(0, 230, 118, 0.2); color: #00e676; border: 1px solid #00e676; }
            .bg-red { background: rgba(255, 23, 68, 0.2); color: #ff1744; border: 1px solid #ff1744; }
            .bg-blue { background: rgba(41, 121, 255, 0.2); color: #448aff; border: 1px solid #448aff; }
            .bg-gray { background: rgba(158, 158, 158, 0.2); color: #bdbdbd; border: 1px solid #9e9e9e; }
            
            /* SCROLLBAR & JADUAL DIPADATKAN */
            .table-container { 
                max-height: 280px; overflow-y: auto; overflow-x: hidden;
                border: 1px solid rgba(255, 255, 255, 0.1); border-radius: 8px; background: rgba(0, 0, 0, 0.2); 
            }
            .table-container::-webkit-scrollbar { width: 4px; }
            .table-container::-webkit-scrollbar-thumb { background: #ff007f; border-radius: 4px; }
            
            .v-table { width: 100%; border-collapse: collapse; }
            .v-table th { 
                position: sticky; top: 0; background: rgba(20, 15, 35, 0.95); 
                font-family: 'Palatino Linotype', serif; 
                color: #00e5ff; padding: 8px 6px; text-align: left; font-size: 0.85em;
                border-bottom: 1px solid rgba(0, 229, 255, 0.3); z-index: 1; 
            }
            /* Kurangkan padding supaya lebih rapat */
            .v-table td { padding: 10px 6px; border-bottom: 1px solid rgba(255,255,255,0.05); vertical-align: middle; }
            
            /* --- SAIZ BUTANG DIKECILKAN --- */
            .btn-pill { border-radius: 20px !important; padding: 8px 12px; font-size: 0.75em; font-weight: bold; border: none; color: #fff !important; cursor: pointer; transition: 0.3s; }
            .btn-on { background: linear-gradient(45deg, #ff1744, #d50000) !important; box-shadow: 0 2px 8px rgba(255,23,68,0.4); }
            .btn-off { background: linear-gradient(45deg, #00e676, #00b0ff) !important; box-shadow: 0 2px 8px rgba(0,230,118,0.4); }
            
            .btn-rect { font-family: 'Trebuchet MS', sans-serif; border-radius: 6px !important; padding: 4px 10px; font-size: 0.75em; font-weight: bold; background: #3d5afe !important; color: #fff !important; border: none !important; cursor: pointer; }
            .btn-outline { font-family: 'Comic Sans MS', cursive, sans-serif; border-radius: 6px !important; padding: 3px 10px; font-size: 0.75em; font-weight: bold; background: transparent !important; color: #ff5252 !important; border: 1px solid #ff5252 !important; cursor: pointer; }
            .btn-outline:hover:not(:disabled) { background: rgba(255, 82, 82, 0.15) !important; }
            
            .btn-leaf { font-family: 'Arial Black', sans-serif; border-radius: 12px 4px 12px 4px !important; padding: 8px 16px; font-size: 0.8em; background: #00e5ff !important; color: #000 !important; border: none !important; cursor: pointer; }
            
            .btn:disabled { opacity: 0.4; cursor: not-allowed; filter: grayscale(100%); }
            
            /* Rapatkan jarak antara dua butang (Aktifkan & Hapus) */
            .btn-group { display: flex; gap: 4px; flex-wrap: wrap; align-items: center; }
            .btn-import-box { display: flex; flex-direction: column; gap: 10px; }
            
            textarea.cbi-input-textarea { background: rgba(0,0,0,0.4) !important; color: #00e5ff !important; font-family: 'Courier New', monospace !important; font-weight: bold !important; border: 1px solid rgba(0, 229, 255, 0.4) !important; border-radius: 8px !important; font-size: 0.85em !important; padding: 10px !important; }
            textarea.cbi-input-textarea:focus { border-color: #ff007f !important; outline: none; }
        `);

        var toggleBtn = E('button', {
            'class': 'btn btn-pill ' + (isRunning ? 'btn-on' : 'btn-off'),
            'style': 'width: 100%;',
            'click': function() {
                ui.showModal(isRunning ? 'Mematikan...' : 'Menghidupkan...', [ E('p', {}, 'Sila tunggu') ]);
                execute([isRunning ? 'disable' : 'enable']).then(function() { window.location.reload(); }).catch(function(err) { ui.hideModal(); ui.addNotification(null, E('p', {}, String(err)), 'danger'); });
            }
        }, isRunning ? 'MATIKAN' : 'HIDUPKAN');

        var globalToggleBtn = E('button', {
            'class': 'btn btn-pill ' + (isGlobalOn ? 'btn-on' : 'btn-off'),
            'style': 'width: 100%;',
            'click': function() {
                if (!isRunning) return;
                ui.showModal(isGlobalOn ? 'Menutup Proksi...' : 'Membuka Proksi...', [ E('p', {}, 'Menyusun semula') ]);
                execute([isGlobalOn ? 'global_disable' : 'global_enable']).then(function() { window.location.reload(); }).catch(function(err) { ui.hideModal(); ui.addNotification(null, E('p', {}, String(err)), 'danger'); });
            }
        }, isGlobalOn ? 'TUTUP PROKSI' : 'BUKA PROKSI');
        
        if (!isRunning) globalToggleBtn.disabled = true;

        var statusSection = E('div', { 'class': 'v-card' }, [
            E('div', { 'class': 'v-card-title' }, '✦ Status Rangkaian'),
            E('div', { 'class': 'status-grid' }, [
                E('div', { 'class': 'status-box' }, [
                    E('h4', {}, 'VLESS Core'),
                    E('span', { 'class': 'badge ' + (isRunning ? 'bg-green' : 'bg-red') }, isRunning ? 'AKTIF' : 'TERHENTI'),
                    toggleBtn
                ]),
                E('div', { 'class': 'status-box' }, [
                    E('h4', {}, 'Global Proxy'),
                    E('span', { 'class': 'badge ' + (isGlobalOn ? 'bg-blue' : 'bg-gray') }, isGlobalOn ? 'BERSAMBUNG' : 'DIPUTUSKAN'),
                    globalToggleBtn
                ])
            ])
        ]);

        var table = E('table', { 'class': 'v-table' }, [
            E('tr', {}, [ E('th', {}, 'Nama Node'), E('th', {}, 'Tindakan') ])
        ]);

        (nodesData.nodes || []).forEach(function(n) {
            var btnActivate = E('button', {
                'class': 'btn btn-rect',
                'click': function() {
                    if (!window.confirm('Tukar ke ' + n.name + '?')) return;
                    ui.showModal('Menukar Node...', [ E('p', {}, 'Sedang menguji...') ]);
                    execute(['switch', n.name]).then(function() { window.location.reload(); }).catch(function(err) { ui.hideModal(); ui.addNotification(null, E('p', {}, String(err)), 'danger'); });
                }
            }, n.active ? 'Berjalan' : 'Aktifkan');
            
            var btnStop = E('button', {
                'class': 'btn btn-rect',
                'click': function() {
                    if (!n.active || !isRunning) return;
                    if (!window.confirm('Berhenti aktifkan ' + n.name + '?')) return;
                    ui.showModal('Menghentikan VLESS...', [
                        E('p', {}, 'Sila tunggu')
                    ]);
                    execute(['stop']).then(function() {
                        window.location.reload();
                    }).catch(function(err) {
                        ui.hideModal();
                        ui.addNotification(null,
                            E('p', {}, String(err)), 'danger');
                    });
                }
            }, 'Berhenti Aktif');

            btnStop.disabled = !(n.active && isRunning);

            var btnEdit = E('button', {
                'class': 'btn btn-rect',
                'style': 'background:#ff9800;color:white;',
                'click': function() {
                    execute(['get', n.name]).then(function(raw) {
                        var cfg = JSON.parse(raw);
                        var o = cfg.outbounds[0];
                        var t = o.transport || {};
                        var fields = [
                            ['Nama Node', n.name],
                            ['Server', o.server || ''],
                            ['Port', String(o.server_port || '')],
                            ['UUID', o.uuid || ''],
                            ['WS Host', (t.headers || {}).Host || ''],
                            ['WS Path', t.path || '/']
                        ];
                        var inputs = fields.map(function(f) {
                            return E('input', {
                                'class': 'cbi-input-text',
                                'style': 'width:100%;margin:5px 0 12px;',
                                'value': f[1]
                            });
                        });
                        var content = [];
                        fields.forEach(function(f, i) {
                            content.push(E('label', {}, f[0]));
                            content.push(inputs[i]);
                        });
                        content.push(E('div', { 'class': 'right' }, [
                            E('button', {
                                'class': 'btn',
                                'click': function() { ui.hideModal(); }
                            }, 'Batal'),
                            E('button', {
                                'class': 'btn btn-primary',
                                'click': function() {
                                    var v = inputs.map(function(x) {
                                        return x.value.trim();
                                    });
                                    var data = JSON.stringify({
                                        name: v[0],
                                        server: v[1],
                                        port: Number(v[2]),
                                        uuid: v[3],
                                        host: v[4],
                                        path: v[5]
                                    });
                                    execute(['save', n.name, data]).then(function() {
                                        ui.hideModal();
                                        window.location.reload();
                                    }).catch(function(err) {
                                        ui.addNotification(null,
                                            E('p', {}, String(err)), 'danger');
                                    });
                                }
                            }, 'Simpan')
                        ]));
                        ui.showModal('Edit Node: ' + n.name, content);
                    }).catch(function(err) {
                        ui.addNotification(null,
                            E('p', {}, String(err)), 'danger');
                    });
                }
            }, 'Edit');
            var btnDelete = E('button', {
                'class': 'btn btn-outline',
                'click': function() {
                    if (!window.confirm('Padam ' + n.name + '?')) return;
                    ui.showModal('Memadam...', [ E('p', {}, 'Sila tunggu') ]);
                    execute(['delete', n.name]).then(function() { window.location.reload(); }).catch(function(err) { ui.hideModal(); ui.addNotification(null, E('p', {}, String(err)), 'danger'); });
                }
            }, 'Hapus');

            if (n.active) {
                btnActivate.disabled = true;
                btnDelete.disabled = true;
                btnEdit.disabled = true;
            }

            // Fon status dikecilkan
            var statusText = E('span', { 
                'style': 'font-family:"Arial", sans-serif; font-weight:bold; font-size:0.75em; color:' + (n.active ? '#00e676' : '#9e9e9e') 
            }, n.active ? 'Aktif' : (NS[n.name] ? (NS[n.name].st === 'DOWN' ? 'Down' : 'Hidup') : 'Disimpan'));
            
            table.appendChild(E('tr', {}, [ 
                // Fon Nama Node dikecilkan ke 0.9em
                E('td', { 'style': 'font-family:"Courier New", monospace; font-weight:bold; font-size:0.9em; color: #ffffff;' }, [n.name, E('div', { 'style': 'margin-top:4px;padding-bottom:6px;font-size:10px;font-weight:normal;font-family:sans-serif;' }, [statusText, ' | ', latencyCell(n.name)])]), 
                 
                E('td', {}, E('div', { 'class': 'vless-node-actions' }, [btnActivate, btnStop, btnEdit, btnDelete])) 
            ]));
        });

        var tableContainer = E('div', { 'class': 'table-container' }, [ table ]);
        var nodeSection = E('div', { 'class': 'v-card' }, [
            E('div', { 'class': 'v-card-title' }, '⎈ Pangkalan Data Node'),
            tableContainer
        ]);

        var input = E('textarea', { 'class': 'cbi-input-textarea', 'rows': 2, 'placeholder': 'Tampal link vless:// di sini...' });
        var importButton = E('button', {
            'class': 'btn btn-leaf',
            'style': 'align-self: flex-start;',
            'click': function() {
                var link = input.value.trim();
                if (!link.startsWith('vless://')) { ui.addNotification(null, E('p', {}, 'Format salah.'), 'warning'); return; }
                importButton.disabled = true;
                execute(['import', link]).then(function() { window.location.reload(); }).catch(function(err) { importButton.disabled = false; ui.addNotification(null, E('p', {}, String(err)), 'danger'); });
            }
        }, 'IMPORT DATA');

        var importSection = E('div', { 'class': 'v-card' }, [
            E('div', { 'class': 'v-card-title' }, '✚ Tambah Node Baharu'),
            E('div', { 'class': 'btn-import-box' }, [ input, importButton ])
        ]);


        var finalMobileStyle = E("style", {}, "/* VLESS_ROW2 */\n.v-dash .v-row2 { display: grid !important; grid-template-columns: 1fr 1fr !important; gap: 8px !important; margin-bottom: 12px !important; align-items: stretch !important; }\n.v-dash .v-row2 > .v-card { margin: 0 !important; padding: 10px !important; min-width: 0 !important; overflow-wrap: anywhere !important; }\n.v-dash .v-row2 .v-card-title { font-size: 0.85em !important; margin-bottom: 6px !important; padding-bottom: 4px !important; }\n.v-dash .v-row2 > .v-card > div { grid-template-columns: 1fr !important; flex-direction: column !important; gap: 6px !important; }\n.v-dash .v-row2 button { font-size: 11px !important; padding: 6px 4px !important; width: 100% !important; }\n.v-dash .v-row2 div { font-size: 11px !important; line-height: 1.35 !important; }\n\n/* VLESS_LATENCY_FIX */\n.v-dash .table-container table { width: 100% !important; min-width: 0 !important; table-layout: fixed !important; }\n.v-dash .table-container th:nth-child(1), .v-dash .table-container td { vertical-align: middle !important; padding-top: 10px !important; padding-bottom: 10px !important; }\n.v-dash .table-container td:nth-child(1) { width: 43% !important; overflow-wrap: anywhere !important; }\n.v-dash .table-container th:nth-child(2), .v-dash .table-container td:nth-child(2) { width: 57% !important; }\n.v-dash .table-container th:nth-child(3), .v-dash .table-container td:nth-child(3) { width: 17% !important; font-size: 11px !important; }\n.v-dash .table-container th:nth-child(4), .v-dash .table-container td:nth-child(4) { width: 45% !important; }\n.vless-node-actions { display: grid !important; grid-template-columns: 1fr 1fr !important; gap: 4px !important; }\n.vless-node-actions button { min-width: 0 !important; width: 100% !important; font-size: 10px !important; padding: 8px 2px !important; white-space: normal !important; }\n\n/* VLESS_MOBILE_FINAL */\n.v-dash .table-container {\n    width: 100% !important;\n    overflow-x: auto !important;\n}\n.v-dash .table-container table {\n    width: 100% !important;\n    table-layout: fixed !important;\n}\n.v-dash .table-container th:nth-child(1),\n.v-dash .table-container td { vertical-align: middle !important; padding-top: 10px !important; padding-bottom: 10px !important; }\n.v-dash .table-container td:nth-child(1) {\n    width: 43% !important;\n    overflow-wrap: anywhere !important;\n}\n.v-dash .table-container th:nth-child(2),\n.v-dash .table-container td:nth-child(2) {\n    width: 57% !important;\n}\n.v-dash .table-container th:nth-child(3),\n.v-dash .table-container td:nth-child(3) {\n    width: 42% !important;\n}\n.vless-node-actions {\n    display: grid !important;\n    grid-template-columns: 1fr 1fr !important;\n    gap: 4px !important;\n}\n.vless-node-actions button {\n    font-size: 10px !important;\n    padding: 8px 2px !important;\n    line-height: 1.2 !important;\n    white-space: normal !important;\n    overflow-wrap: normal !important;\n    word-break: normal !important;\n}\n");
        // VLESS_WAN_UI_V1
        // VLESS_MOBILE_GRID_V2
        var mobileGridStyle = E('style', {}, `
.vless-node-actions {
    display: grid !important;
    grid-template-columns: repeat(2, minmax(0, 1fr)) !important;
    gap: 5px !important;
    width: 100% !important;
}
.vless-node-actions button {
    box-sizing: border-box !important;
    min-width: 0 !important;
    max-width: 100% !important;
    width: 100% !important;
    padding: 7px 3px !important;
    font-size: 11px !important;
    white-space: normal !important;
    overflow-wrap: anywhere !important;
}
`);

        var wanBox = E('div', { 'class': 'v-card' }, [
            E('div', { 'class': 'v-card-title' }, 'Auto WAN Detection'),
            E('div', { 'id': 'vless-wan-details' }, 'Mengesan WAN...')
        ]);

        execute(['wan_info']).then(function(r) {
            var target = document.getElementById('vless-wan-details');
            if (!target) return;
            var w = JSON.parse(r || '{}');
            target.replaceChildren(
                E('div', {}, 'Interface: ' + (w.interface || '-')),
                E('div', {}, 'IP WAN: ' + (w.ip || '-')),
                E('div', {}, 'Gateway: ' + (w.gateway || '-')),
                E('div', {}, 'DNS: ' + (w.dns || '-')),
                E('div', {}, 'ISP/Telco: ' + (w.isp || '-'))
            );
        }).catch(function() {});

        if (!document.getElementById('v3-monitor-script')) { var s = document.createElement('script'); s.id = 'v3-monitor-script'; s.src = '/luci-static/v3-monitor.js'; document.head.appendChild(s); }
        setTimeout(function() { var p = document.createElement('script'); p.src = '/luci-static/v3-panel.js'; document.head.appendChild(p); }, 1500);
        if (!document.getElementById('v3-panel-script')) { var p = document.createElement('script'); p.id = 'v3-panel-script'; p.src = '/luci-static/v3-panel.js'; document.head.appendChild(p); }
        return E('div', { 'class': 'v-dash cbi-map' }, [
            style,
            mobileGridStyle,
            finalMobileStyle,
            E('h2', { 'style': 'font-family: "Arial Black", sans-serif; color: #ffffff; font-size: 1.6em; text-transform: uppercase; margin-bottom: 2px; text-shadow: 2px 2px 0px #b8005c;' }, 'VLESS Manager Pro V2'),
            E('p', { 'style': 'font-family: "Trebuchet MS", sans-serif; color: #ffeb3b; font-weight: bold; font-size: 0.85em; margin-bottom: 18px; letter-spacing: 1px;' }, 'Sistem Proksi Global (Geometrik)'),
            E('div', { 'class': 'v-row2' }, [statusSection, wanBox]),
            
            nodeSection,
            importSection,
            E('div', { 'class': 'v-card' }, [
                E('div', { 'class': 'v-card-title' }, 'VLESS Manager Pro V3 - Modul Tambahan'),
                E('p', {}, 'Ujian sambungan TCP untuk semua node VLESS'), E('button', { 'class': 'btn btn-primary', 'click': function() { var out = document.getElementById('v3-latency-result'); out.textContent = 'Sedang menguji 9 node...'; fetch('/cgi-bin/vless-v3-control?action=ping').then(function(r) { if (!r.ok) throw new Error('HTTP ' + r.status); return r.text(); }).then(function(t) { out.textContent = t; }).catch(function(e) { out.textContent = 'Ralat: ' + e.message; }); } }, 'UJI LATENCY SEMUA NODE'), E('pre', { 'id': 'v3-latency-result', 'style': 'white-space:pre-wrap;overflow-wrap:anywhere;background:#180b23;color:#00f5d4;padding:12px;border-radius:8px;font-size:12px;margin-top:12px;' }, 'Tekan butang untuk menguji semua node.')
            ])
        ]);
    },
    handleSaveApply: null, handleSave: null, handleReset: null
});
