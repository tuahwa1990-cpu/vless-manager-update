'use strict';
'require view';
'require fs';
'require ui';

var command = '/usr/libexec/vless-manager';

function execute(args) {
    return fs.exec(command, args).then(function(r) {
        if (r.code !== 0) throw new Error((r.stdout || r.stderr || 'Operation failed').trim());
        return (r.stdout || '').trim();
    });
}

function fail(e) {
    ui.hideModal();
    ui.addNotification(null, E('p', {}, String(e.message || e)), 'danger');
}

function act(args, msg) {
    ui.showModal(null, [ E('p', { 'class': 'spinning' }, msg) ]);
    return execute(args).then(function() { window.location.reload(); }).catch(fail);
}

var CSS = [
 '.v4 { font-family: sans-serif; color: #fff; }',
 '.v4 .hero { background: linear-gradient(135deg,#3b0a5e,#8a0b4f); border-radius: 16px; padding: 14px; margin-bottom: 10px; }',
 '.v4 .hero-top { display: flex; align-items: center; gap: 10px; }',
 '.v4 .dot { width: 12px; height: 12px; border-radius: 50%; background: #ff5555; box-shadow: 0 0 8px #ff5555; flex: none; }',
 '.v4 .dot.on { background: #00e676; box-shadow: 0 0 10px #00e676; }',
 '.v4 .hero h2 { margin: 0; font-size: 1.1em; color: #ffeb3b; text-transform: uppercase; }',
 '.v4 .hero small { color: #ddd; }',
 '.v4 .active-name { font-family: monospace; font-weight: bold; font-size: 0.95em; margin-top: 8px; overflow-wrap: anywhere; }',
 '.v4 .toggles { display: grid; grid-template-columns: 1fr 1fr; gap: 8px; margin-top: 10px; }',
 '.v4 .tg { border: none; border-radius: 12px; padding: 10px 4px; font-weight: bold; font-size: 12px; color: #fff; cursor: pointer; }',
 '.v4 .tg.on { background: #0a8f4e; } .v4 .tg.off { background: #b3122e; }',
 '.v4 .chips { display: flex; flex-wrap: wrap; gap: 6px; margin-bottom: 10px; }',
 '.v4 .chip { background: rgba(255,255,255,.08); border-radius: 10px; padding: 4px 8px; font-size: 10px; }',
 '.v4 .grid { display: grid; grid-template-columns: 1fr; gap: 8px; }',
 '@media (min-width: 640px) { .v4 .grid { grid-template-columns: 1fr 1fr; } }',
 '.v4 .card { background: rgba(255,255,255,.06); border: 1px solid rgba(255,255,255,.12); border-radius: 14px; padding: 10px; }',
 '.v4 .card.act { border-color: #00e676; box-shadow: 0 0 14px rgba(0,230,118,.45); }',
 '.v4 .nm { font-family: monospace; font-weight: bold; font-size: 12px; overflow-wrap: anywhere; }',
 '.v4 .meta { display: flex; align-items: center; gap: 8px; margin: 6px 0; font-size: 11px; }',
 '.v4 .badge { border-radius: 8px; padding: 2px 7px; font-size: 10px; font-weight: bold; }',
 '.v4 .b-ok { background: #0a8f4e; } .v4 .b-act { background: #1565c0; } .v4 .b-down { background: #b3122e; }',
 '.v4 .bars { display: inline-flex; align-items: flex-end; gap: 2px; height: 13px; }',
 '.v4 .bars i { width: 3px; background: rgba(255,255,255,.2); display: block; }',
 '.v4 .bars i.f { background: currentColor; }',
 '.v4 .row { display: flex; gap: 6px; }',
 '.v4 .row button { flex: 1; border: none; border-radius: 10px; padding: 8px 4px; font-size: 11px; font-weight: bold; color: #fff; background: #3d5afe; cursor: pointer; }',
 '.v4 .row button.g { background: rgba(255,255,255,.12); flex: none; width: 36px; }',
 '.v4 .row button.stop { background: #b3122e; }',
 '.v4 .more { display: none; gap: 6px; margin-top: 6px; }',
 '.v4 .more.open { display: flex; }',
 '.v4 .more button { flex: 1; border: none; border-radius: 10px; padding: 7px 4px; font-size: 11px; background: #3d5afe; color: #fff; }',
 '.v4 .more button.del { background: transparent; border: 1px solid #ff5252; color: #ff5252; }',
 '.v4 details { background: rgba(255,255,255,.06); border-radius: 14px; margin-top: 10px; padding: 0 12px; }',
 '.v4 summary { padding: 12px 0; font-weight: bold; color: #ffeb3b; cursor: pointer; }',
 '.v4 details > div { padding-bottom: 12px; }',
 '.v4 textarea { width: 100%; min-height: 70px; background: #1b0a26; color: #fff; border: 1px solid #555; border-radius: 10px; font-family: monospace; font-size: 11px; }',
 '.v4 .pri { background: #00e5ff; color: #000; border: none; border-radius: 10px; padding: 9px 14px; font-weight: bold; margin-top: 8px; }',
 '#v3-monitor-panel { display: grid !important; grid-template-columns: 1fr 1fr; gap: 8px; padding: 8px !important; margin: 10px 0 !important; border-radius: 14px !important; }',
 '#v3-monitor-panel > h3, #v3-monitor-panel > pre, #v3-monitor-panel > canvas { grid-column: 1 / -1; margin: 0 !important; }',
 '#v3-monitor-panel > pre { font-size: 10px !important; padding: 6px !important; line-height: 1.3 !important; }',
 '#v3-monitor-panel > canvas { height: 90px !important; }',
 '#v3-recovery-box, #v3-autoswitch-box { margin-top: 0 !important; padding: 8px !important; min-width: 0; font-size: 11px; }',
 '#v3-recovery-box h4, #v3-autoswitch-box h4, #v3-recovery-box h3, #v3-autoswitch-box h3 { font-size: 11px !important; margin: 0 0 4px !important; }',
 '#v3-recovery-box button, #v3-autoswitch-box button { font-size: 10px !important; padding: 4px 8px !important; }',
 '.v4 .sec-title { color: #ffeb3b; font-weight: bold; font-size: 1.05em; margin: 14px 2px 8px; padding-bottom: 4px; border-bottom: 1px dashed rgba(255,235,59,.4); }',
  '.v4 { padding-bottom: 70px; }',
 '.v4[data-tab="u"] .t-n, .v4[data-tab="u"] .t-l, .v4[data-tab="n"] .t-u, .v4[data-tab="n"] .t-l, .v4[data-tab="l"] .t-u, .v4[data-tab="l"] .t-n { display: none !important; }',
 '.v4:not([data-tab="u"]) #v3-monitor-panel { display: none !important; }',
 '.tabbar { position: fixed; left: 0; right: 0; bottom: 0; display: flex; background: #1b0a26; border-top: 1px solid rgba(255,255,255,.15); z-index: 1000; }',
 '.tabbar button { flex: 1; border: none; background: transparent; color: #bbb; padding: 14px 4px; font-size: 13px; font-weight: bold; }',
 '.tabbar button.on { color: #ffeb3b; border-top: 3px solid #ffeb3b; }',
  '.v4 .throw { display: flex; gap: 6px; }',
 '.v4 .thbtn { flex: 1; border: 1px solid rgba(255,255,255,.3); background: transparent; color: #fff; border-radius: 10px; padding: 10px 4px; font-size: 12px; font-weight: bold; }',
 '.v4 .thbtn.on { background: #3d5afe; border-color: #3d5afe; }',
 '.v4[data-theme="n"] .hero { background: linear-gradient(135deg, #001f3f, #00838f); }',
 '.v4[data-theme="n"] .card { background: rgba(0,229,255,.06); border-color: rgba(0,229,255,.4); }',
 '.v4[data-theme="n"] .card.act { border-color: #76ff03; box-shadow: 0 0 14px rgba(118,255,3,.5); }',
 '.v4[data-theme="n"] .sec-title, .v4[data-theme="n"] summary, .v4[data-theme="n"] .hero h2 { color: #00e5ff; }',
 '.v4[data-theme="n"] .row button, .v4[data-theme="n"] .more button { background: #00acc1; }',
 '.v4[data-theme="n"] .row button.stop { background: #b3122e; }',
 '.v4[data-theme="n"] .tabbar { background: #001018; }',
 '.v4[data-theme="n"] .tabbar button.on { color: #00e5ff; border-top-color: #00e5ff; }',
 '.v4[data-theme="a"] .hero { background: #000; border: 1px solid #333; }',
 '.v4[data-theme="a"] .card, .v4[data-theme="a"] details { background: #000; border: 1px solid #2a2a2a; }',
 '.v4[data-theme="a"] .card.act { border-color: #00e676; box-shadow: none; }',
 '.v4[data-theme="a"] .chip { background: #111; }',
 '.v4[data-theme="a"] .sec-title, .v4[data-theme="a"] summary, .v4[data-theme="a"] .hero h2 { color: #ddd; }',
 '.v4[data-theme="a"] .row button, .v4[data-theme="a"] .more button { background: #1e40af; }',
 '.v4[data-theme="a"] .row button.stop { background: #8b0f24; }',
 '.v4[data-theme="a"] .tabbar { background: #000; }',
 '.v4[data-theme="a"] #v3-monitor-panel { background: #000 !important; border: 1px solid #2a2a2a; }',
 '.v4[data-theme="n"] { --v3bg:#001a24; --v3bd:#00acc1; --v3cv:#000d12; --v3pre:#00141c; }',
    '.v4[data-theme="a"] { --v3bg:#000; --v3bd:#2a2a2a; --v3cv:#050505; --v3pre:#0b0b0b; }',
    '.v4 .pkbar { display:flex; align-items:center; gap:10px; padding:14px 16px; margin:6px 0 10px; border-radius:14px; background:rgba(128,128,128,.2); border:1px solid rgba(128,128,128,.35); cursor:pointer; font-size:15px; }',
    '.v4 .pkbar b { flex:1; }',
    '.v4 .pkov { display:none; position:fixed; left:0; top:0; right:0; bottom:0; z-index:9999; background:rgba(0,0,0,.7); align-items:center; justify-content:center; }',
    '.v4 .pkov.open { display:flex; }',
    '.v4 .pkbox { width:92%; max-width:420px; max-height:80vh; overflow:auto; background:#1c1c1e; color:#fff; border-radius:14px; padding:8px 0; }',
    '.v4 .pkh { padding:14px 18px; font-weight:bold; opacity:.8; }',
    '.v4 .pki { display:flex; justify-content:space-between; gap:12px; padding:14px 18px; font-size:16px; cursor:pointer; }',
    '.v4 .pki span:first-child { min-width:0; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; }',
    '.v4 .pki span:last-child { white-space:nowrap; }',
    '.v4 .pki.on { background:rgba(0,200,120,.18); }',
    '.v4 .pkc { display:block; width:100%; background:none; border:0; color:#fff; text-align:left; padding:14px 18px; font-size:16px; }',
    '.v4[data-theme="n"] { --pw:#00e5ff; --pw2:#00acc1; --pwg:rgba(0,229,255,.5); }',
    '.v4[data-theme="a"] { --pw:#e0e0e0; --pw2:#7a7a7a; --pwg:rgba(255,255,255,.25); }',
    '.v4 .pw { text-align:center; margin:14px 0 10px; }',
    '.v4 .pwst { opacity:.85; font-size:15px; }',
    '.v4 .pwbtn { width:190px; height:190px; border-radius:50%; margin:16px auto; display:flex; flex-direction:column; align-items:center; justify-content:center; cursor:pointer; color:#fff; border:4px solid var(--pw,#ffd600); }',
    '.v4 .pwbtn.on { background:radial-gradient(circle at 50% 40%, var(--pw,#ffd600), var(--pw2,#b89b00)); box-shadow:0 0 34px var(--pwg,rgba(255,214,0,.5)); color:#141414; }',
    '.v4 .pwbtn.off { background:transparent; color:var(--pw,#ffd600); box-shadow:0 0 18px var(--pwg,rgba(255,214,0,.3)); }',
    '.v4 .pwt { font-size:15px; font-weight:bold; margin-top:8px; }',
    '.v4 .pwtm { font-size:34px; font-weight:bold; line-height:1.2; color:var(--pw,#ffd600); letter-spacing:2px; }',
    '.v4 .pwsl { font-size:12px; opacity:.7; letter-spacing:2px; }',
    '.v4 .pwsp { display:flex; justify-content:space-around; margin-top:12px; padding:12px; border-radius:14px; background:rgba(128,128,128,.2); font-weight:bold; }',
    '.v4[data-tab="u"] .t-s, .v4[data-tab="n"] .t-s, .v4[data-tab="l"] .t-s { display:none !important; }',
    '.v4[data-tab="s"] .t-u, .v4[data-tab="s"] .t-n, .v4[data-tab="s"] .t-l { display:none !important; }',
    '.v4 .stcard { background:rgba(128,128,128,.18); border:1px solid rgba(128,128,128,.3); border-radius:16px; padding:4px 14px; margin-bottom:14px; }',
    '.v4 .strow { display:flex; align-items:center; gap:12px; padding:13px 0; border-bottom:1px solid rgba(128,128,128,.25); font-size:14px; }',
    '.v4 .stcard .strow:last-child { border-bottom:0; }',
    '.v4 .stbox { padding-bottom:80px; }',
    '.v4 .stbar { height:6px; border-radius:3px; background:rgba(128,128,128,.3); margin:0 0 14px; }',
    '.v4 .stfill { height:100%; width:0; border-radius:3px; background:var(--pw,#ffd600); }',
    '.v4 .sti { width:26px; text-align:center; }',
    '.v4 .stl { opacity:.8; min-width:84px; }',
    '.v4 .stv { flex:1; text-align:right; font-weight:bold; word-break:break-all; }',
    '.v4 .strf { background:rgba(128,128,128,.3); border:0; color:inherit; border-radius:10px; padding:6px 12px; font-size:16px; }',
    '.v4 pre { white-space: pre-wrap; overflow-wrap: anywhere; background: var(--v3pre,#180b23); color: #00f5d4; padding: 10px; border-radius: 8px; font-size: 11px; }'
].join('\n');

function latInfo(s) {
    if (!s) return { txt: '-', col: '#bbb', lv: 0, st: '' };
    if (s.st === 'DOWN') return { txt: 'Down', col: '#ff5555', lv: 0, st: 'DOWN' };
    var ms = s.ms;
    var col = ms < 150 ? '#00e676' : (ms < 400 ? '#ffd600' : '#ff5555');
    var lv = ms < 100 ? 4 : (ms < 250 ? 3 : (ms < 500 ? 2 : 1));
    return { txt: ms + ' ms', col: col, lv: lv, st: s.st };
}

function bars(lv, col) {
    var hs = [4, 7, 10, 13];
    return E('span', { 'class': 'bars', 'style': 'color:' + col }, hs.map(function(h, i) {
        return E('i', { 'class': (i < lv ? 'f' : ''), 'style': 'height:' + h + 'px' });
    }));
}

function editNode(n) {
    execute(['get', n.name]).then(function(out) {
        var o;
        try { o = JSON.parse(out); } catch (e) { throw new Error('Format data node tidak dikenali: ' + out.substring(0, 120)); }
        var f = [ ['Nama', o.name || n.name], ['Server', o.server || ''], ['Port', o.port || ''], ['UUID', o.uuid || ''], ['Host', o.host || ''], ['Path', o.path || ''] ];
        var inputs = f.map(function(x) { return E('input', { 'class': 'cbi-input-text', 'style': 'width:100%', 'value': x[1] }); });
        var content = [];
        f.forEach(function(x, i) { content.push(E('label', {}, x[0]), inputs[i]); });
        content.push(E('div', { 'class': 'right', 'style': 'margin-top:10px' }, [
            E('button', { 'class': 'btn', 'click': function() { ui.hideModal(); } }, 'Batal'), ' ',
            E('button', { 'class': 'btn cbi-button-positive', 'click': function() {
                var v = inputs.map(function(x) { return x.value.trim(); });
                var data = JSON.stringify({ name: v[0], server: v[1], port: Number(v[2]), uuid: v[3], host: v[4], path: v[5] });
                act(['save', n.name, data], 'Menyimpan...');
            } }, 'Simpan')
        ]));
        ui.showModal('Edit Node: ' + n.name, content);
    }).catch(fail);
}

var TABS = [['u', 'Utama'], ['n', 'Node'], ['l', 'Lagi'], ['s', 'Status']];
function setupTabs(r) {
    var map = ['', 'u', 'u', 'u', 'n', 'n', 'n', 'n', 'l', 'l', 'l', 's'];
    for (var i = 0; i < r.children.length && i < map.length; i++)
        if (map[i]) r.children[i].classList.add('t-' + map[i]);
    var bar = E('div', { 'class': 'tabbar' }, TABS.map(function(t) {
        return E('button', { 'data-k': t[0], 'click': function() { show(t[0]); } }, t[1]);
    }));
    function show(k) {
        r.setAttribute('data-tab', k);
        Array.prototype.forEach.call(bar.children, function(b) { b.classList.toggle('on', b.getAttribute('data-k') === k); });
        try { sessionStorage.setItem('v4tab', k); } catch (e) {}
    }
    r.appendChild(bar);
    var k0 = 'u';
    try { k0 = sessionStorage.getItem('v4tab') || 'u'; } catch (e) {}
    show(k0);
}

var THEMES = [['g', 'Geometrik'], ['n', 'Neon Siber'], ['a', 'AMOLED']];
function setupTheme(r) {
    var btns = THEMES.map(function(t) {
        return E('button', { 'class': 'thbtn', 'data-k': t[0], 'click': function() { apply(t[0]); } }, t[1]);
    });
    function apply(k) {
        r.setAttribute('data-theme', k);
        try { document.body.style.backgroundColor = (k === 'a') ? '#000' : ''; } catch (e) {}
        btns.forEach(function(b) { b.classList.toggle('on', b.getAttribute('data-k') === k); });
        try { localStorage.setItem('v4theme', k); } catch (e) {}
    }
    var box = E('details', { 'class': 't-l' }, [ E('summary', {}, 'Tema Paparan'), E('div', { 'class': 'throw' }, btns) ]);
    r.insertBefore(box, r.querySelector('.tabbar'));
    var k0 = 'g';
    try { k0 = localStorage.getItem('v4theme') || 'g'; } catch (e) {}
    apply(k0);
}

return view.extend({
    load: function() {
        return Promise.all([
            execute(['list']).then(function(s) { return JSON.parse(s); }),
            execute(['status']).catch(function() { return 'STOPPED'; }),
            execute(['global_status']).catch(function() { return 'OFF'; }),
            execute(['node_status']).catch(function() { return ''; }),
            execute(['wan_info']).catch(function() { return '{}'; })
        ]);
    },

    render: function(d) {
        var r = this.render0(d);
        setupTabs(r);
        setupTheme(r);
        return r;
    },

    render0: function(d) {
        var nodes = (d[0] && d[0].nodes) || [];
        var running = (d[1] === 'RUNNING');
        var gon = (d[2] === 'ON');
        var NS = {};
        String(d[3] || '').split('\n').forEach(function(l) {
            var p = l.split('|');
            if (p.length === 3) NS[p[0]] = { st: p[1], ms: parseInt(p[2], 10) };
        });
        var wan = {};
        try { wan = JSON.parse(d[4] || '{}'); } catch (e) {}

        var activeName = (d[0] && d[0].active) || '-';
        var al = latInfo(NS[activeName]);

        var pwOn = (running && gon);
        var pwSess = E('div', { 'class': 'pwtm' }, '00:00:00');
        var pwDl = E('span', {}, '\u2193 0 B/s');
        var pwUl = E('span', {}, '\u2191 0 B/s');
        var pwIcon = E('span', { 'class': 'pwi' });
        pwIcon.innerHTML = '<svg viewBox="0 0 24 24" width="64" height="64" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><path d="M12 3v9"/><path d="M6.4 6.6a8 8 0 1 0 11.2 0"/></svg>';
        function pwT(sec) { sec = Math.max(0, sec | 0); function p(x) { return (x < 10 ? '0' : '') + x; } return p(Math.floor(sec / 3600)) + ':' + p(Math.floor(sec / 60) % 60) + ':' + p(sec % 60); }
        function pwS(b) { if (b < 0) b = 0; if (b >= 1048576) return (b / 1048576).toFixed(2) + ' MB/s'; if (b >= 1024) return (b / 1024).toFixed(1) + ' KB/s'; return Math.round(b) + ' B/s'; }
        var pwLast = null;
        var pwTimer = setInterval(function() {
            if (pwSess.isConnected) pwSess._seen = true;
            else if (pwSess._seen) { clearInterval(pwTimer); return; }
            else return;
            fetch('/cgi-bin/vless-session', { cache: 'no-store' }).then(function(r) { return r.text(); }).then(function(t) {
                var p = t.trim().split('\n').pop().split('|');
                if (p.length != 3) return;
                var now = Date.now(), rx = parseFloat(p[1]), tx = parseFloat(p[2]);
                pwSess.textContent = pwT(parseInt(p[0], 10));
                if (pwLast && now > pwLast.t) {
                    var dt = (now - pwLast.t) / 1000;
                    pwDl.textContent = '\u2193 ' + pwS((rx - pwLast.rx) / dt);
                    pwUl.textContent = '\u2191 ' + pwS((tx - pwLast.tx) / dt);
                }
                pwLast = { t: now, rx: rx, tx: tx };
            }).catch(function() {});
        }, 2000);
        (function() {
    var s = document.createElement('style');
    s.textContent = '.v4 .hbg{width:40px!important;min-width:0!important;height:40px!important;padding:0!important;margin-right:10px;border-radius:10px;border:1px solid var(--pw,#7c4dff);background:transparent;color:var(--pw,#7c4dff);font-size:22px;line-height:1;flex:0 0 auto;align-self:center;padding:0}' +
    '.v4 .dwov{position:fixed;inset:0;z-index:99999;background:rgba(0,0,0,.55);opacity:0;pointer-events:none;transition:opacity .2s}' +
    '.v4 .dwov.on{opacity:1;pointer-events:auto}' +
    '.v4 .dwp{position:absolute;top:0;bottom:0;left:0;width:78%;max-width:320px;background:#14121c;color:#eee;transform:translateX(-100%);transition:transform .22s;padding:18px 12px;overflow:auto;box-shadow:4px 0 20px rgba(0,0,0,.5)}' +
    '.v4 .dwov.on .dwp{transform:none}' +
    '.v4 .dwt{font-size:22px;font-weight:800;color:var(--pw,#7c4dff);margin:4px 8px 18px}' +
    '.v4 .dws{font-size:11px;letter-spacing:1.5px;opacity:.55;margin:16px 8px 6px;font-weight:700}' +
    '.v4 .dwi{display:flex;align-items:center;gap:14px;width:100%;padding:13px 10px;border:0;border-radius:12px;background:transparent;color:inherit;font-size:16px;text-align:left}' +
    '.v4 .dwi:active{background:rgba(255,255,255,.08)}' +
    '.v4 .dwi b{font-size:20px;width:26px;text-align:center;color:var(--pw,#7c4dff)}' +
    '.v4 .dwi em{margin-left:auto;font-size:10px;opacity:.5;font-style:normal}' +
    '.v4 .dwtoast{position:absolute;left:50%;bottom:30px;transform:translateX(-50%);background:#333;color:#fff;padding:9px 16px;border-radius:20px;font-size:13px;opacity:0;transition:opacity .2s;pointer-events:none}' +
    '.v4 .dwtoast.on{opacity:1}';
    document.head.appendChild(s);
})();
var dwOv = null, dwTo = null, dwTt = null;
function dwClose() { if (dwOv) dwOv.classList.remove('on'); }
function dwToast(m) {
    dwTo.textContent = m;
    dwTo.classList.add('on');
    clearTimeout(dwTt);
    dwTt = setTimeout(function() { dwTo.classList.remove('on'); }, 1800);
}
function dwGo(k, then) {
    dwClose();
    var b = document.querySelector('.v4 .tabbar button[data-k="' + k + '"]');
    if (b) b.click();
    if (then) setTimeout(then, 80);
}
function dwOpenBox(box) {
    return function() {
        box.open = true;
        try { box.scrollIntoView({ behavior: 'smooth', block: 'start' }); } catch (e) {}
    };
}
function dwBuild() {
    var items = [
        ['NAVIGATE'],
        ['\u2263', 'Logs', function() { logsOpen(); }],
        ['\u21C4', 'Routing', function() { routeOpen(); }],
        ['\u2699', 'Settings', function() { setOpen(); }],
        ['\u25A3', 'System', function() { sysOpen(); }],
        ['\u2605', 'Activation & License', function() { licOpen(); }],
        ['APP'],
        ['\u2601', 'Update', function() { updateOpen(); }],
        ['\u24D8', 'About', function() { aboutOpen(); }],
        ['\u21AA', 'Log Out', function() { location.href = '/cgi-bin/luci/admin/logout'; }]
    ];
    var kids = [E('div', { 'class': 'dwt' }, 'VLESS Manager Pro')];
    items.forEach(function(it) {
        if (it.length === 1) kids.push(E('div', { 'class': 'dws' }, it[0]));
        else kids.push(E('button', { 'class': 'dwi', 'click': it[2] }, [E('b', {}, it[0]), it[1], it[3] ? E('em', {}, it[3]) : '']));
    });
    dwTo = E('div', { 'class': 'dwtoast' }, '');
    dwOv = E('div', { 'class': 'dwov', 'click': function(ev) { if (ev.target === dwOv) dwClose(); } }, [
        E('div', { 'class': 'dwp' }, kids), dwTo
    ]);
}
function dwOpen() {
    if (licLocked) return;
    var root = document.querySelector('.v4');
    if (!root) return;
    if (!dwOv) dwBuild();
    if (dwOv.parentNode !== root) root.appendChild(dwOv);
    setTimeout(function() { dwOv.classList.add('on'); }, 10);
}
var hbg = E('button', { 'class': 'hbg', 'click': dwOpen }, '\u2630');

(function() {
    var s = document.createElement('style');
    s.textContent = '.v4 .pgov{position:fixed;inset:0;z-index:99998;background:#0e0c14;color:#eee;overflow:auto;transform:translateX(100%);transition:transform .22s;visibility:hidden}' +
    '.v4 .pgov.on{transform:none;visibility:visible}' +
    '.v4 .pgh{display:flex;align-items:center;gap:12px;padding:14px 12px;position:sticky;top:0;background:#14121c;border-bottom:1px solid rgba(255,255,255,.08);z-index:2}' +
    '.v4 .pgback{width:40px!important;min-width:0!important;height:40px!important;padding:0!important;border-radius:10px;border:1px solid var(--pw,#7c4dff);background:transparent;color:var(--pw,#7c4dff);font-size:20px}' +
    '.v4 .pgt{font-size:20px;font-weight:800}' +
    '.v4 .pgb{padding:12px}' +
    '.v4 .syc{border:1px solid rgba(255,255,255,.12);border-radius:14px;padding:12px 14px;margin:0 0 12px;background:rgba(255,255,255,.03)}' +
    '.v4 .syh{font-weight:800;color:var(--pw,#7c4dff);margin-bottom:8px}' +
    '.v4 .syr{display:flex;justify-content:space-between;gap:12px;padding:6px 0;font-size:14px;border-bottom:1px solid rgba(255,255,255,.06)}' +
    '.v4 .syr:last-child{border-bottom:0}' +
    '.v4 .syr span{opacity:.7}.v4 .syr b{text-align:right;word-break:break-all}' +
    '.v4 .syb{height:8px;border-radius:4px;background:rgba(255,255,255,.1);margin:6px 0 8px;overflow:hidden}' +
    '.v4 .syb i{display:block;height:100%;background:var(--pw,#7c4dff);border-radius:4px}';
    document.head.appendChild(s);
})();
var pgOv = null, pgBody = null, pgTitle = null, pgTm = null;
function pgClose() {
    if (licLocked) return;
    if (pgOv) pgOv.classList.remove('on');
    try { lgBox.open = false; sgBox.open = false; } catch (e) {}
    clearInterval(pgTm);
    pgTm = null;
}
function pgOpen(title, el, refresh) {
    var root = document.querySelector('.v4');
    if (!root) return;
    if (!pgOv) {
        pgTitle = E('div', { 'class': 'pgt' }, '');
        pgBody = E('div', { 'class': 'pgb' });
        pgOv = E('div', { 'class': 'pgov' }, [
            E('div', { 'class': 'pgh' }, [E('button', { 'class': 'pgback', 'click': function() { pgClose(); dwOpen(); } }, '\u2190'), pgTitle]),
            pgBody
        ]);
    }
    if (pgOv.parentNode !== root) root.appendChild(pgOv);
    try { lgBox.open = false; sgBox.open = false; } catch (e) {}
    pgTitle.textContent = title;
    while (pgBody.firstChild) pgBody.removeChild(pgBody.firstChild);
    pgBody.appendChild(el);
    clearInterval(pgTm);
    pgTm = null;
    dwClose();
    setTimeout(function() { pgOv.classList.add('on'); }, 10);
    if (refresh) { refresh(); pgTm = setInterval(refresh, 5000); }
}
var syBody = E('div', {});
function syRow(l, v) { return '<div class="syr"><span>' + grEsc(l) + '</span><b>' + grEsc(v) + '</b></div>'; }
function syBar(p) { return '<div class="syb"><i style="width:' + Math.max(0, Math.min(100, p)).toFixed(0) + '%"></i></div>'; }
function syCard(t, rows) { return '<div class="syc"><div class="syh">' + grEsc(t) + '</div>' + rows + '</div>'; }
function syUp(s) {
    var d = Math.floor(s / 86400), h = Math.floor(s % 86400 / 3600), m = Math.floor(s % 3600 / 60);
    return (d ? d + ' hari ' : '') + h + ' jam ' + m + ' min';
}
function syKb(k) { return fmtB(k * 1024); }
function syLoad() {
    fetch('/cgi-bin/vless-system?_=' + Date.now(), { cache: 'no-store' }).then(function(r) { return r.text(); }).then(function(t) {
        var o = {};
        t.split('\n').forEach(function(l) {
            var i = l.indexOf('=');
            if (i > 0) o[l.slice(0, i)] = l.slice(i + 1);
        });
        var h = '';
        h += syCard('Peranti', syRow('Model', o.model || '-') + syRow('Firmware', o.fw || '-') + syRow('Kernel', o.kernel || '-') + syRow('IP LAN', o.lanip || '-') + syRow('Uptime', syUp(+o.up || 0)));
        var cores = +o.cores || 1, ld = (o.load || '0 0 0').split(' ');
        h += syCard('CPU', syBar((+ld[0] || 0) / cores * 100) + syRow('Beban (1/5/15 min)', ld.join(' / ')) + syRow('Teras', String(cores)) + (o.temp ? syRow('Suhu', ((+o.temp) / 1000).toFixed(0) + ' \u00B0C') : ''));
        var mm = (o.mem || '0,0').split(','), mt = +mm[0] || 1, mu = mt - (+mm[1] || 0);
        h += syCard('Memori (RAM)', syBar(mu / mt * 100) + syRow('Digunakan', syKb(mu) + ' / ' + syKb(mt) + ' (' + (mu / mt * 100).toFixed(0) + '%)'));
        var ov = (o.ovl || '0,0').split(','), ot = +ov[0] || 1, ou = +ov[1] || 0;
        var tm = (o.tmp || '0,0').split(','), tt = +tm[0] || 1, tu = +tm[1] || 0;
        h += syCard('Simpanan', syBar(ou / ot * 100) + syRow('Overlay (USB)', syKb(ou) + ' / ' + syKb(ot)) + syRow('/tmp (RAM)', syKb(tu) + ' / ' + syKb(tt)));
        h += syCard('sing-box', syRow('Versi', (o.sb || '-').replace('sing-box version ', '')) + syRow('Memori proses', o.sbmem ? syKb(+o.sbmem) : '-'));
        syBody.innerHTML = h;
    }).catch(function() {});
}
function sysOpen() { pgOpen('System', syBody, syLoad); }

var abBody = E('div', {});
function abLoad() {
    fetch('/cgi-bin/vless-system?_=' + Date.now(), { cache: 'no-store' }).then(function(r) { return r.text(); }).then(function(t) {
        var o = {};
        t.split('\n').forEach(function(l) {
            var i = l.indexOf('=');
            if (i > 0) o[l.slice(0, i)] = l.slice(i + 1);
        });
        abBody.innerHTML =
            syCard('VLESS Manager Pro', syRow('Paparan', 'Panel v4') + syRow('Teras proksi', (o.sb || '-').replace('sing-box version ', 'sing-box ')) + syRow('Mod', 'Proksi global (tproxy)')) +
            syCard('Ciri', syRow('Pilih node', 'Ya') + syRow('Auto switch / pulih', 'Ya (modul V3)') + syRow('Statistik & graf', 'Ya') + syRow('Log sing-box', 'Ya') + syRow('Reboot berjadual', 'Ya')) +
            syCard('Peranti', syRow('Model', o.model || '-') + syRow('Firmware', o.fw || '-'));
    }).catch(function() {});
}
function aboutOpen() { pgOpen('About', abBody); abLoad(); }

(function() {
    var s = document.createElement('style');
    s.textContent = '.v4 .rtb{font-size:12px;padding:3px 10px;border-radius:10px;border:1px solid var(--pw,#7c4dff);color:var(--pw,#7c4dff);white-space:nowrap}' +
    '.v4 .rtb.blk{border-color:#e5484d;color:#e5484d}';
    document.head.appendChild(s);
})();
var rtBody = E('div', {});
function rtDesc(spec) {
    var o = {};
    spec.split(' ').forEach(function(t) {
        var i = t.indexOf(':');
        if (i > 0) o[t.slice(0, i)] = t.slice(i + 1);
    });
    var k = Object.keys(o);
    if (k.length === 1 && o.port === '53') return 'DNS (port 53)';
    if (k.length === 2 && o.network === 'udp' && o.port === '443') return 'QUIC (UDP port 443)';
    if (k.length === 1 && o.network === 'udp') return 'UDP lain-lain';
    return spec.replace(/:/g, ' = ');
}
function rtOut(ob, fin) {
    if (ob === 'direct-out') return ['Terus (tanpa proksi)', ''];
    if (ob === 'block-out') return ['Disekat', ' blk'];
    return ['Proksi: ' + (ob === fin ? ob : ob), ''];
}
function rtRow(d, ob, fin) {
    var r = rtOut(ob, fin);
    return '<div class="syr"><span>' + grEsc(d) + '</span><b class="rtb' + r[1] + '">' + grEsc(r[0]) + '</b></div>';
}
function rtLoad() {
    fetch('/cgi-bin/vless-routing?_=' + Date.now(), { cache: 'no-store' }).then(function(r) { return r.text(); }).then(function(t) {
        var rules = [], fin = '';
        t.split('\n').forEach(function(l) {
            if (l.indexOf('rule=') === 0) {
                var v = l.slice(5), i = v.lastIndexOf('|');
                if (i > 0) rules.push([v.slice(0, i), v.slice(i + 1)]);
            } else if (l.indexOf('final=') === 0) fin = l.slice(6);
        });
        var h = '', rows = '';
        rules.forEach(function(r, i) { rows += rtRow((i + 1) + '. ' + rtDesc(r[0]), r[1], fin); });
        rows += rtRow((rules.length + 1) + '. Semua trafik lain', fin, fin);
        h += syCard('Peraturan (ikut urutan)', rows || syRow('-', 'Tiada'));
        h += syCard('Nota', '<div style="font-size:13px;opacity:.8;line-height:1.5">Halaman ini hanya paparan. Paket UDP yang disekat (contohnya QUIC) akan muncul sebagai baris ralat "operation not permitted" dalam log. Ini normal, aplikasi akan beralih ke TCP secara automatik. Mengubah peraturan memerlukan restart sing-box.</div>');
        rtBody.innerHTML = h;
    }).catch(function() {});
}
function routeOpen() { pgOpen('Routing', rtBody); rtLoad(); }

(function() {
    var s = document.createElement('style');
    s.textContent = '.v4 .pgb .lgbox>summary{display:none}.v4 .pgb .lgbox{border:0;padding:0;margin:0}';
    document.head.appendChild(s);
})();
function logsOpen() { pgOpen('Logs', lgBox, lgLoad); lgBox.open = true; }
function setOpen() { pgOpen('Settings', sgBox); sgBox.open = true; }

    var updSt = document.createElement('style');
    updSt.textContent = '.v4 .sgrow input[type=checkbox]{width:24px;height:24px;flex:0 0 auto}.v4 .sgrow input[type=time]{width:110px;flex:0 0 auto}';
    document.head.appendChild(updSt);

    function updVer(a) {
        return String(a || '').split('.').map(function(x) { return parseInt(x, 10) || 0; });
    }
    function updNewer(a, b) {
        var x = updVer(a), y = updVer(b);
        for (var i = 0; i < 3; i++) {
            if ((x[i] || 0) > (y[i] || 0)) return true;
            if ((x[i] || 0) < (y[i] || 0)) return false;
        }
        return false;
    }
    function updateOpen() {
        var st = E('div', { 'style': 'font-size:18px;font-weight:700;margin:6px 0 10px' }, ['Menyemak...']);
        var rows = E('div', { 'style': 'font-size:14px;line-height:1.9' }, []);
        var link = E('a', { 'href': '#', 'target': '_blank', 'rel': 'noopener', 'style': 'display:none;margin:10px 0;color:var(--pw, currentColor);font-weight:600' }, ['Lihat nota keluaran \u2192']);
        var btn = E('button', { 'class': 'cbi-button', 'style': 'margin-top:8px !important;padding:10px 20px !important;border:1.5px solid var(--pw, currentColor) !important;border-radius:10px !important;background:transparent !important;color:var(--pw, currentColor) !important;font-size:15px !important;height:auto !important;line-height:1.2 !important' }, ['Semak sekarang']);
        var note = E('div', { 'style': 'margin-top:14px;font-size:12px;opacity:.7' },
            ['Semakan sahaja. Tiada apa dipasang secara automatik. Pemasangan sing-box dibuat secara manual.']);
        var el = E('div', { 'style': 'padding:14px' }, [st, rows, link, btn, note]);
        function show(t, ts) {
            var o = {};
            String(t || '').split('\n').forEach(function(l) {
                var i = l.indexOf('=');
                if (i > 0) o[l.substring(0, i)] = l.substring(i + 1).trim();
            });
            var chk = o.checked ? new Date(parseInt(o.checked, 10) * 1000).toLocaleString() : '-';
            rows.textContent = 'Dipasang: ' + (o.current || '-') + '  |  Terkini: ' + (o.latest || '-') + '  |  Disemak: ' + chk;
            if (!o.latest) {
                st.textContent = 'Gagal menyemak';
                link.style.display = 'none';
            } else if (updNewer(o.latest, o.current)) {
                st.textContent = 'Versi baharu tersedia: ' + o.latest;
                link.href = 'https://github.com/SagerNet/sing-box/releases/tag/v' + o.latest;
                link.style.display = 'inline-block';
            } else {
                st.textContent = 'Sudah terkini';
                link.style.display = 'none';
            }
        }
        function load(force) {
            st.textContent = 'Menyemak...';
            fetch('/cgi-bin/vless-update' + (force ? '?force=1' : ''))
                .then(function(r) { return r.text(); })
                .then(show)
                .catch(function() { st.textContent = 'Gagal menyemak'; });
        }
        btn.addEventListener('click', function() { load(true); });
                var apBs = 'margin:8px 8px 0 0 !important;padding:10px 20px !important;border:1.5px solid var(--pw, currentColor) !important;border-radius:10px !important;background:transparent !important;color:var(--pw, currentColor) !important;font-size:15px !important;height:auto !important;line-height:1.2 !important';
        var apSt = E('div', { 'style': 'font-size:13px;margin:8px 0;word-break:break-word' }, ['']);
        var apBtn = E('button', { 'class': 'cbi-button', 'style': apBs }, ['Pilih fail update']);
        var apGo = E('button', { 'class': 'cbi-button', 'style': apBs + ';display:none' }, ['Pasang sekarang']);
        var apBox = E('div', { 'style': 'margin-top:22px;padding-top:14px;border-top:1px solid rgba(128,128,128,.4)' }, [
            E('div', { 'style': 'font-size:16px;font-weight:700' }, ['Update aplikasi (fail)']),
            apSt, apBtn, apGo
        ]);
        el.appendChild(apBox);
        function apVer() {
            fetch('/cgi-bin/vless-upgrade?a=ver').then(function(r) { return r.text(); }).then(function(t) {
                var m = /app=(\S+)/.exec(t);
                apSt.textContent = 'Versi aplikasi: ' + (m ? m[1] : '-');
            }).catch(function() {});
        }
        var gtSt = E('div', { 'style': 'font-size:13px;margin:8px 0;word-break:break-word' }, ['']);
        var gtBtn = E('button', { 'class': 'cbi-button', 'style': apBs }, ['Semak update aplikasi']);
        var gtGo = E('button', { 'class': 'cbi-button', 'style': apBs + ';display:none' }, ['Muat turun & pasang']);
        apBox.appendChild(E('div', { 'style': 'margin-top:16px;padding-top:12px;border-top:1px dashed rgba(128,128,128,.4)' }, [
            E('div', { 'style': 'font-size:15px;font-weight:700' }, ['Dari GitHub']),
            gtSt, gtBtn, gtGo
        ]));
        gtBtn.addEventListener('click', function() {
            gtGo.style.display = 'none';
            gtSt.textContent = 'Menyemak...';
            fetch('/cgi-bin/vless-appupdate').then(function(r) { return r.text(); }).then(function(t) {
                var c = /cur=(\S+)/.exec(t), l = /latest=(\S+)/.exec(t);
                var cv = c ? c[1] : '-';
                if (!l) { gtSt.textContent = String(t).trim() || 'Gagal menyemak'; return; }
                if (updNewer(l[1], cv)) {
                    gtSt.textContent = 'Versi baharu: ' + l[1] + ' (dipasang: ' + cv + ')';
                    gtGo.style.display = 'inline-block';
                } else {
                    gtSt.textContent = 'Sudah terkini (' + cv + ')';
                }
            }).catch(function() { gtSt.textContent = 'Gagal menyemak'; });
        });
        gtGo.addEventListener('click', function() {
            gtGo.style.display = 'none';
            gtSt.textContent = 'Memuat turun dan memasang...';
            fetch('/cgi-bin/vless-appupdate?a=install&sid=' + ((L.env && L.env.sessionid) || '')).then(function(r) { return r.text(); }).then(function(t) {
                t = String(t).trim();
                if (t.indexOf('OK pasang') === 0) {
                    gtSt.textContent = 'Berjaya. ' + t.replace('OK pasang ', '') + ' Memuat semula...';
                    setTimeout(function() { location.reload(); }, 2500);
                } else {
                    gtSt.textContent = t;
                }
            }).catch(function() { gtSt.textContent = 'Pemasangan gagal'; });
        });
        apVer();
        apBtn.addEventListener('click', function() {
            apGo.style.display = 'none';
            L.require('ui').then(function(ui) {
                return ui.uploadFile('/tmp/vless-upd.tar.gz', apBtn);
            }).then(function() {
                apSt.textContent = 'Menyemak fail...';
                return fetch('/cgi-bin/vless-upgrade?a=check').then(function(r) { return r.text(); });
            }).then(function(t) {
                t = String(t).trim();
                apSt.textContent = t;
                if (t.indexOf('OK semak') === 0) {
                    apSt.textContent = 'Fail sah. ' + t.replace('OK semak ', '');
                    apGo.style.display = 'inline-block';
                }
            }).catch(function() { apSt.textContent = 'Muat naik gagal'; });
        });
        apGo.addEventListener('click', function() {
            apGo.style.display = 'none';
            apSt.textContent = 'Memasang...';
            fetch('/cgi-bin/vless-upgrade?a=apply').then(function(r) { return r.text(); }).then(function(t) {
                t = String(t).trim();
                if (t.indexOf('OK pasang') === 0) {
                    apSt.textContent = 'Berjaya. ' + t.replace('OK pasang ', '') + ' Memuat semula...';
                    setTimeout(function() { location.reload(); }, 2500);
                } else {
                    apSt.textContent = t;
                }
            }).catch(function() { apSt.textContent = 'Pemasangan gagal'; });
        });
        pgOpen('Update', el, function() {});
        load(false);
    }

        function licOpen() {
        var lbs = 'margin:8px 8px 0 0 !important;padding:10px 20px !important;border:1.5px solid var(--pw, currentColor) !important;border-radius:10px !important;background:transparent !important;color:var(--pw, currentColor) !important;font-size:15px !important;height:auto !important;line-height:1.2 !important';
        var lbadge = E('div', { 'style': 'font-size:20px;font-weight:700;margin:6px 0 4px' }, ['Menyemak...']);
        var lsub = E('div', { 'style': 'font-size:13px;opacity:.75;margin-bottom:14px' }, ['']);
        var lid = E('input', { 'type': 'text', 'readonly': 'readonly', 'style': 'width:100%;box-sizing:border-box;padding:10px;border:1px solid rgba(128,128,128,.5);border-radius:8px;background:transparent;color:inherit;font-family:monospace;font-size:15px' }, []);
        var lcopy = E('button', { 'class': 'cbi-button', 'style': lbs }, ['Salin ID']);
        var lkey = E('textarea', { 'rows': '4', 'placeholder': 'Tampal kunci lesen di sini', 'style': 'width:100%;box-sizing:border-box;padding:10px;border:1px solid rgba(128,128,128,.5);border-radius:8px;background:transparent;color:inherit;font-family:monospace;font-size:13px;margin-top:6px' }, []);
        var lgo = E('button', { 'class': 'cbi-button', 'style': lbs }, ['Aktifkan']);
        var lmsg = E('div', { 'style': 'font-size:13px;margin-top:10px;word-break:break-word' }, ['']);
        var el = E('div', { 'style': 'padding:14px' }, [
            lbadge, lsub,
            E('div', { 'style': 'font-size:13px;opacity:.75;margin-bottom:4px' }, ['ID Peranti (hantar kepada penjual untuk mendapatkan kunci)']),
            lid, lcopy,
            E('div', { 'style': 'font-size:13px;opacity:.75;margin:18px 0 0' }, ['Kunci lesen']),
            lkey, lgo, lmsg
        ]);
        function lshow(t) {
            var o = {};
            String(t || '').split('\n').forEach(function(l) {
                var i = l.indexOf('=');
                if (i > 0) o[l.substring(0, i)] = l.substring(i + 1).trim();
            });
            if (o.id) lid.value = o.id;
            var s = o.state || '';
            var exp = o.exp || '0';
            var expTxt = (exp === '0') ? 'Lesen seumur hidup' : ('Sah sehingga ' + exp.substring(0, 4) + '-' + exp.substring(4, 6) + '-' + exp.substring(6, 8));
            lsub.textContent = '';
            if (s === 'active') { lbadge.textContent = 'Aktif'; lsub.textContent = expTxt; }
            else if (s === 'expired') { lbadge.textContent = 'Lesen tamat tempoh'; lsub.textContent = 'Tamat pada ' + exp.substring(0, 4) + '-' + exp.substring(4, 6) + '-' + exp.substring(6, 8); }
            else if (s === 'wrongdevice') { lbadge.textContent = 'Kunci bukan untuk peranti ini'; }
            else if (s === 'invalid') { lbadge.textContent = 'Kunci tidak sah'; }
            else if (s === 'none') { lbadge.textContent = 'Belum diaktifkan'; }
            else if (s.indexOf('ERR') === 0) { lbadge.textContent = 'Sesi tamat'; lsub.textContent = 'Log masuk semula ke LuCI, kemudian cuba lagi.'; }
            else { lbadge.textContent = 'Gagal menyemak'; }
            return s;
        }
        function lload() {
            fetch('/cgi-bin/vless-license').then(function(r) { return r.text(); }).then(lshow)
                .catch(function() { lbadge.textContent = 'Gagal menyemak'; });
        }
        lcopy.addEventListener('click', function() {
            try {
                lid.focus(); lid.select(); lid.setSelectionRange(0, 99);
                var ok = document.execCommand && document.execCommand('copy');
                lmsg.textContent = ok ? 'ID disalin.' : 'Tekan lama pada ID untuk menyalin.';
            } catch (e) { lmsg.textContent = 'Tekan lama pada ID untuk menyalin.'; }
        });
        lgo.addEventListener('click', function() {
            var k = lkey.value.replace(/\s+/g, '');
            if (!k) { lmsg.textContent = 'Tampal kunci dahulu.'; return; }
            lmsg.textContent = 'Mengesahkan...';
            fetch('/cgi-bin/vless-license?a=activate&sid=' + ((L.env && L.env.sessionid) || '') + '&key=' + encodeURIComponent(k))
                .then(function(r) { return r.text(); }).then(function(t) {
                    var s = lshow(t);
                    if (s === 'active') { lmsg.textContent = 'Berjaya diaktifkan. Memuat semula...'; setTimeout(function() { location.reload(); }, 1800); }
                    else lmsg.textContent = '';
                }).catch(function() { lmsg.textContent = 'Gagal mengesahkan.'; });
        });
        pgOpen('Activation & License', el, function() {});
        lload();
    }

        var licLocked = false;
    fetch('/cgi-bin/vless-license').then(function(r) { return r.text(); }).then(function(t) {
        if (/state=(none|invalid|wrongdevice)/.test(t)) {
            licLocked = true;
            licOpen();
        }
    }).catch(function() {});

    var hero = E('div', { 'class': 'hero' }, [
            E('div', { 'class': 'hero-top' }, [
                hbg,
                E('span', { 'class': 'dot' + ((running && gon) ? ' on' : '') }),
                E('div', {}, [
                    E('h2', {}, 'VLESS Manager Pro'),
                    E('small', {}, (running ? 'Core aktif' : 'Core mati') + ' | ' + (gon ? 'Proksi global ON' : 'Proksi global OFF'))
                ])
            ]),
            E('div', { 'class': 'active-name' }, [ activeName + '  ', E('span', { 'style': 'color:' + al.col }, al.txt) ]),
            E('div', { 'class': 'pw' }, [
                E('div', { 'class': 'pwst' }, pwOn ? 'Status : Connected' : 'Status : Disconnected'),
                E('button', { 'class': 'pwbtn ' + (pwOn ? 'on' : 'off'), 'click': function() {
                    if (pwOn) {
                        if (!window.confirm('Putuskan proksi global? Trafik akan terus tanpa proksi.')) return;
                        act(['global_disable'], 'Memutuskan proksi...');
                    } else if (!running) {
                        act(['enable'], 'Menyambung core...');
                    } else {
                        act(['global_enable'], 'Menyambung proksi...');
                    }
                } }, [ pwIcon, E('span', { 'class': 'pwt' }, pwOn ? 'Disconnect' : 'Tap to connect') ]),
                pwSess,
                E('div', { 'class': 'pwsl' }, 'SESSION'),
                E('div', { 'class': 'pwsp' }, [ pwDl, pwUl ])
            ]),
            E('div', { 'class': 'toggles' }, [
                E('button', { 'class': 'tg ' + (running ? 'off' : 'on'), 'click': function() { act([running ? 'disable' : 'enable'], 'Sila tunggu...'); } }, running ? 'MATIKAN CORE' : 'HIDUPKAN CORE'),
                E('button', { 'class': 'tg ' + (gon ? 'off' : 'on'), 'click': function() { act([gon ? 'global_disable' : 'global_enable'], 'Sila tunggu...'); } }, gon ? 'TUTUP PROKSI' : 'BUKA PROKSI')
            ])
        ]);

        var chips = E('div', { 'class': 'chips' }, [
            E('span', { 'class': 'chip' }, 'Interface: ' + (wan.interface || '-')),
            E('span', { 'class': 'chip' }, 'IP WAN: ' + (wan.ip || '-')),
            E('span', { 'class': 'chip' }, 'Gateway: ' + (wan.gateway || '-')),
            E('span', { 'class': 'chip' }, 'DNS: ' + (wan.dns || '-')),
            E('span', { 'class': 'chip' }, 'ISP/Telco: ' + (wan.isp || '-'))
        ]);

        var activeNode = nodes.filter(function(n) { return n.active; })[0];
        var pickList = E('div', { 'class': 'pklist' });
        var pickOv = E('div', { 'class': 'pkov', 'click': function(ev) {
            ev.stopPropagation();
            if (ev.target === pickOv) pickOv.classList.remove('open');
        } }, [ E('div', { 'class': 'pkbox' }, [
            E('div', { 'class': 'pkh' }, 'Select Profile or Group'),
            pickList,
            E('button', { 'class': 'pkc', 'click': function() { pickOv.classList.remove('open'); } }, 'Cancel')
        ]) ]);
        nodes.forEach(function(n) {
            var li = latInfo(NS[n.name]);
            pickList.appendChild(E('div', { 'class': 'pki' + (n.active ? ' on' : ''), 'click': function() {
                pickOv.classList.remove('open');
                if (n.active) return;
                act(['switch', n.name], 'Menukar node, sila tunggu...');
            } }, [ E('span', {}, n.name), E('span', { 'style': 'color:' + (n.active ? '#00e676' : li.col) }, n.active ? 'Aktif' : li.txt) ]));
        });
        var pickBar = E('div', { 'class': 'pkbar', 'click': function() { pickOv.classList.add('open'); } }, [
            E('span', {}, '\u2630'),
            E('b', {}, activeNode ? activeNode.name : 'Pilih node'),
            E('span', {}, '\u25BE'),
            pickOv
        ]);
        function stRow(ic, label, val, extra) {
            var kids = [ E('span', { 'class': 'sti' }, ic), E('span', { 'class': 'stl' }, label), val ];
            if (extra) kids.push(extra);
            return E('div', { 'class': 'strow' }, kids);
        }
        var stV = {};
        ['tun', 'wan', 'ram', 'pub', 'cty', 'isp', 'mode', 'up', 'trf', 'wip', 'gw', 'd1', 'd2', 'drp'].forEach(function(k) { stV[k] = E('span', { 'class': 'stv' }, '...'); });
        var stFill = E('div', { 'class': 'stfill' });
        var stBar = E('div', { 'class': 'stbar' }, [ stFill ]);
        var stLast = 0;
        function fmtB(b) { b = Number(b) || 0; if (b >= 1073741824) return (b / 1073741824).toFixed(2) + ' GB'; if (b >= 1048576) return (b / 1048576).toFixed(1) + ' MB'; if (b >= 1024) return Math.round(b / 1024) + ' KB'; return Math.round(b) + ' B'; }
        function stLoad() {
            stLast = Date.now();
            stV.tun.textContent = 'Menguji...';
            fetch('/cgi-bin/vless-session', { cache: 'no-store' }).then(function(r) { return r.text(); }).then(function(t) {
                var p = t.trim().split('\n').pop().split('|');
                stV.up.textContent = pwT(parseInt(p[0], 10));
            }).catch(function() {});
            fetch('/cgi-bin/vless-status', { cache: 'no-store' }).then(function(r) { return r.text(); }).then(function(t) {
                var o = {};
                t.split('\n').forEach(function(l) { var i = l.indexOf('='); if (i > 0) o[l.slice(0, i)] = l.slice(i + 1).split('|'); });
                var tn = o.tunnel || [], g = o.geo || [], rm = o.ram || [], md = o.mode || [], tr = o.traffic || [], w = o.wan || [];
                var ok = (tn[0] === '204');
                stV.tun.textContent = ok ? ('Internet OK \u00B7 ' + tn[1] + ' ms') : 'Tiada internet melalui terowong';
                stV.tun.style.color = ok ? '' : '#ff5252';
                stV.wan.textContent = (w[0] || '-') + (w[5] === 'true' ? ' up' : ' down') + ' \u00B7 ' + (w[6] || 0) + ' drops';
                var pct = rm[1] ? Math.round(rm[0] * 100 / rm[1]) : 0;
                stV.ram.textContent = rm[0] + ' / ' + rm[1] + ' MB \u00B7 ' + pct + '%';
                stFill.style.width = pct + '%';
                stV.pub.textContent = g[0] || '-';
                stV.cty.textContent = (g[1] || '-') + (g[2] ? ' (' + g[2] + ')' : '');
                stV.isp.textContent = g[3] || '-';
                stV.mode.textContent = (md[0] || '-') + ' \u00B7 sing-box ' + (md[1] || '-');
                stV.trf.textContent = '\u2193 ' + fmtB(tr[0]) + ' \u00B7 \u2191 ' + fmtB(tr[1]);
                stV.wip.textContent = (w[1] || '-') + ' [' + (w[0] || '-') + ']';
                stV.gw.textContent = w[2] || '-';
                stV.d1.textContent = w[3] || '-';
                stV.d2.textContent = w[4] || 'Tiada';
                stV.drp.textContent = (parseInt(w[6], 10) > 0) ? (w[6] + ' dalam log') : 'Tiada dalam log';
            }).catch(function() { stV.tun.textContent = 'Ralat memuatkan data'; });
        }
        var lgLvl = 'ALL', lgCut = '', lgRaw = [], lgTm = null;
(function() {
    var s = document.createElement('style');
    s.textContent = '.v4 .lgbox{border:1px solid var(--v3bd,#444);border-radius:14px;padding:10px 12px;margin:10px 0}' +
    '.v4 .lgbox>summary{font-weight:700;cursor:pointer}' +
    '.v4 .lgbar{display:flex;gap:6px;margin:10px 0;flex-wrap:wrap}' +
    '.v4 .lgbar button{padding:6px 10px;border-radius:9px;border:1px solid var(--v3bd,#444);background:transparent;color:inherit;font-size:12px}' +
    '.v4 .lgbar button.on{border:2px solid var(--pw,#7c4dff);color:var(--pw,#7c4dff);font-weight:700}' +
    '.v4 .lgl{max-height:360px;overflow:auto;font-family:monospace;font-size:11px;line-height:1.35}' +
    '.v4 .lgr{display:flex;gap:6px;padding:5px 0;border-bottom:1px solid var(--v3bd,#333);align-items:flex-start}' +
    '.v4 .lgt{flex:0 0 52px;opacity:.7}' +
    '.v4 .lgb{flex:0 0 40px;text-align:center;border-radius:5px;padding:1px 0;font-size:10px;font-weight:700;background:rgba(128,128,128,.25)}' +
    '.v4 .lgb.WARN{background:#b8860b;color:#fff}.v4 .lgb.ERROR,.v4 .lgb.FATAL{background:#e5484d;color:#fff}' +
    '.v4 .lgm{flex:1;word-break:break-all}';
    document.head.appendChild(s);
})();
function lgEsc(s) { return String(s).replace(/[&<>"]/g, function(c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }
function lgTime(d, t) {
    var x = new Date(d + 'T' + t + 'Z');
    if (isNaN(x.getTime())) return t;
    return new Date(x.getTime() + 8 * 3600000).toISOString().slice(11, 19);
}
var lgList = E('div', { 'class': 'lgl' }, 'Memuatkan...');
function lgDraw() {
    var out = '', n = 0;
    for (var i = lgRaw.length - 1; i >= 0 && n < 120; i--) {
        var m = /^(\d{4}-\d\d-\d\d) (\d\d:\d\d:\d\d) (\w+) (.*)$/.exec(lgRaw[i]);
        if (!m) continue;
        if (lgCut && (m[1] + ' ' + m[2]) <= lgCut) continue;
        var lv = m[3];
        if (lgLvl === 'WARN' && lv !== 'WARN' && lv !== 'ERROR' && lv !== 'FATAL') continue;
        if (lgLvl === 'ERROR' && lv !== 'ERROR' && lv !== 'FATAL') continue;
        out += '<div class="lgr"><div class="lgt">' + lgTime(m[1], m[2]) + '</div><div class="lgb ' + lv + '">' + lv + '</div><div class="lgm">' + lgEsc(m[4]) + '</div></div>';
        n++;
    }
    lgList.innerHTML = out || '<div style="opacity:.6;padding:8px 0">Tiada log.</div>';
}
function lgLoad() {
    fetch('/cgi-bin/vless-log', { cache: 'no-store' }).then(function(r) { return r.text(); }).then(function(t) {
        lgRaw = t.split('\n').filter(function(x) { return x !== ''; });
        lgDraw();
    }).catch(function() {});
}
var lgBtns = {};
function lgSetLvl(l) {
    lgLvl = l;
    for (var k in lgBtns) lgBtns[k].className = (k === l) ? 'on' : '';
    lgDraw();
}
['ALL', 'WARN', 'ERROR'].forEach(function(l) {
    lgBtns[l] = E('button', { 'class': (l === 'ALL') ? 'on' : '', 'click': function() { lgSetLvl(l); } }, (l === 'ALL') ? 'Semua' : (l === 'WARN' ? 'Amaran' : 'Ralat'));
});
var lgBox = E('details', { 'class': 'lgbox', 'toggle': function() {
    if (lgBox.open) {
        lgLoad();
        if (!lgTm) lgTm = setInterval(function() { if (lgBox.open) lgLoad(); }, 3000);
    }
} }, [
    E('summary', {}, 'Log sing-box'),
    E('div', { 'class': 'lgbar' }, [
        lgBtns.ALL, lgBtns.WARN, lgBtns.ERROR,
        E('button', { 'click': lgLoad }, '\u21BB'),
        E('button', { 'click': function() {
            for (var i = lgRaw.length - 1; i >= 0; i--) {
                var m = /^(\d{4}-\d\d-\d\d \d\d:\d\d:\d\d) /.exec(lgRaw[i]);
                if (m) { lgCut = m[1]; break; }
            }
            lgDraw();
        } }, 'Kosongkan')
    ]),
    lgList
]);

(function() {
    var s = document.createElement('style');
    s.textContent = '.v4 .sgrow{margin:12px 0}' +
    '.v4 .sgrow label{display:block;font-weight:700;margin-bottom:6px}' +
    '.v4 .sginp{width:100%;box-sizing:border-box;padding:9px;border-radius:9px;border:1px solid var(--v3bd,#444);background:transparent;color:inherit;font-size:13px;margin-bottom:6px}' +
    '.v4 .sgmsg{font-size:12px;opacity:.8;min-height:16px}' +
    '.v4 .sgnote{font-size:12px;opacity:.7;margin:8px 0}';
    document.head.appendChild(s);
})();
var sgMsg = E('div', { 'class': 'sgmsg' }, '');
var sgPing = E('input', { 'class': 'sginp', 'type': 'text', 'placeholder': 'https://www.gstatic.com/generate_204' });
var sgOn = E('input', { 'type': 'checkbox' });
var sgTime = E('input', { 'class': 'sginp', 'type': 'time' });
function sgApply(t) {
    var o = {};
    t.split('\n').forEach(function(l) {
        var i = l.indexOf('=');
        if (i > 0) o[l.slice(0, i)] = l.slice(i + 1);
    });
    if (o.ping) sgPing.value = o.ping;
    sgOn.checked = (o.reboot === '1');
    if (o.reboot === '1') {
        var h = ('0' + (+o.rh || 0)).slice(-2), m = ('0' + (+o.rm || 0)).slice(-2);
        sgTime.value = h + ':' + m;
    } else if (!sgTime.value) sgTime.value = '04:00';
    sgMsg.textContent = o.msg ? (o.msg === 'OK' ? 'Disimpan.' : (o.msg === 'reset' ? 'Ping URL dikembalikan ke asal.' : 'Ralat: ' + o.msg)) : '';
}
function sgCall(qs) {
    fetch('/cgi-bin/vless-settings?' + qs + '&_=' + Date.now(), { cache: 'no-store' }).then(function(r) { return r.text(); }).then(sgApply).catch(function() { sgMsg.textContent = 'Gagal menghubungi router.'; });
}
var sgBox = E('details', { 'class': 'lgbox', 'toggle': function() { if (sgBox.open) sgCall('a=get'); } }, [
    E('summary', {}, 'Tetapan'),
    E('div', { 'class': 'sgrow' }, [
        E('label', {}, 'Ping URL (semakan tunnel)'),
        sgPing,
        E('div', { 'class': 'lgbar' }, [
            E('button', { 'click': function() { sgCall('a=ping&u=' + encodeURIComponent(sgPing.value.trim())); } }, 'Simpan'),
            E('button', { 'click': function() { sgCall('a=ping&u='); } }, 'Asal')
        ])
    ]),
    E('div', { 'class': 'sgrow' }, [
        E('label', {}, 'Reboot berjadual (setiap hari, waktu Malaysia)'),
        E('div', { 'style': 'display:flex;align-items:center;gap:10px' }, [sgOn, sgTime]),
        E('div', { 'class': 'lgbar' }, [
            E('button', { 'click': function() {
                var p = (sgTime.value || '04:00').split(':');
                sgCall('a=reboot&on=' + (sgOn.checked ? 1 : 0) + '&h=' + (+p[0]) + '&m=' + (+p[1]));
            } }, 'Simpan')
        ])
    ]),
    sgMsg,
    E('div', { 'class': 'sgnote' }, 'Auto-pulih sedang aktif (dijalankan setiap minit oleh modul V3). Tukar kata laluan: LuCI \u2192 System \u2192 Administration.')
]);

var grMode = 'ov', grRange = '24', grD = null;
(function() {
    var s = document.createElement('style');
    s.textContent = '.v4 .grseg{display:flex;gap:6px;margin:0 0 10px}' +
    '.v4 .grseg button{flex:1;padding:8px;border-radius:10px;border:1px solid var(--v3bd,#444);background:transparent;color:inherit;font-weight:600}' +
    '.v4 .grseg button.on{background:transparent;border:2px solid var(--pw,#7c4dff);color:var(--pw,#7c4dff)}' +
    '.v4 .grc{border:1px solid var(--v3bd,#444);border-radius:14px;padding:12px;margin:0 0 10px}' +
    '.v4 .grh{display:flex;justify-content:space-between;align-items:center;font-weight:700;margin-bottom:6px}' +
    '.v4 .grh span{font-weight:400;opacity:.7;font-size:12px}' +
    '.v4 .grsum{display:flex;gap:14px;font-size:13px;margin:4px 0 8px;flex-wrap:wrap}' +
    '.v4 .grsum b{display:block;font-size:16px}' +
    '.v4 .grsvg{width:100%;height:90px;display:block}' +
    '.v4 .grnd{display:flex;align-items:center;gap:8px;font-size:12px;margin:6px 0}' +
    '.v4 .grnd i{display:block;height:6px;border-radius:3px;background:var(--pw,#7c4dff)}' +
    '.v4 .grnm{flex:0 0 38%;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}' +
    '.v4 .grtl{display:flex;gap:2px;margin-top:6px}' +
    '.v4 .grtl i{flex:1;height:14px;border-radius:2px;background:var(--pw,#7c4dff);opacity:.35}' +
    '.v4 .grtl i.bad{background:#e5484d;opacity:1}';
    document.head.appendChild(s);
})();
function grEsc(s) { return String(s).replace(/[&<>"]/g, function(c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }
function grPairs(s) {
    return (s || '').split(';').filter(function(x) { return x !== ''; }).map(function(p) {
        var a = p.split(',');
        return [+a[0] || 0, +a[1] || 0];
    });
}
function grParse(t) {
    var o = {};
    t.split('\n').forEach(function(l) {
        var i = l.indexOf('=');
        if (i < 1) return;
        var k = l.slice(0, i), v = l.slice(i + 1);
        if (k === 'node') { (o.nodes = o.nodes || []).push(v.split('|')); }
        else o[k] = v;
    });
    return o;
}
function grMb(b) { return (b * 8 / 60 / 1e6); }
function grLine(vals, max, color) {
    var n = vals.length, pts = [];
    if (n < 2 || max <= 0) return '';
    for (var i = 0; i < n; i++) pts.push((i * 300 / (n - 1)).toFixed(1) + ',' + (88 - vals[i] / max * 84).toFixed(1));
    return '<polyline fill="none" stroke="' + color + '" stroke-width="2" vector-effect="non-scaling-stroke" points="' + pts.join(' ') + '"/>';
}
function grSvg(inner) {
    return '<svg class="grsvg" viewBox="0 0 300 90" preserveAspectRatio="none"><line x1="0" y1="89" x2="300" y2="89" stroke="currentColor" opacity=".2"/>' + inner + '</svg>';
}
function grCard(title, sub, extra) {
    var body = E('div', {});
    var card = E('div', { 'class': 'grc' }, [
        E('div', { 'class': 'grh' }, [E('div', {}, title), E('span', {}, sub || '')]),
        body
    ]);
    if (extra) card.firstChild.appendChild(extra);
    return { card: card, body: body };
}
var grSpd = grCard('Speed', 'Live, last hour');
var grUseBtn = E('button', { 'class': 'strf', 'click': function() {
    grRange = (grRange === '24') ? '30' : '24';
    grUseBtn.textContent = (grRange === '24') ? '24h' : '30 hari';
    grDraw();
} }, '24h');
var grUse = grCard('Data usage', '', grUseBtn);
var grTun = grCard('Tunnel latency', '24 jam');
var grDrp = grCard('WAN drops', '24 jam');
function grDraw() {
    var d = grD;
    if (!d) return;
    setTimeout(grSpdDraw, 0);
    var sp = grPairs(d.spd).reverse();
    var rxs = sp.map(function(p) { return grMb(p[0]); });
    var txs = sp.map(function(p) { return grMb(p[1]); });
    var mx = Math.max.apply(null, rxs.concat(txs).concat([0.1]));
    var cur = grPairs(d.spd)[1] || [0, 0];
    grSpd.body.innerHTML = '<div class="grsum"><div>Download<b>' + grMb(cur[0]).toFixed(2) + ' Mbps</b></div><div>Upload<b>' + grMb(cur[1]).toFixed(2) + ' Mbps</b></div><div>Puncak<b>' + mx.toFixed(2) + '</b></div></div>' +
        grSvg(grLine(rxs, mx, 'var(--pw,#7c4dff)') + grLine(txs, mx, 'var(--pw2,#aaa)'));
    var arr = grPairs(grRange === '24' ? d.hrs : d.days).reverse();
    var tr = 0, tt = 0, bm = 1, bars = '';
    arr.forEach(function(p) { tr += p[0]; tt += p[1]; if (p[0] + p[1] > bm) bm = p[0] + p[1]; });
    var w = 300 / arr.length;
    arr.forEach(function(p, i) {
        var hr = p[0] / bm * 84, ht = p[1] / bm * 84;
        bars += '<rect x="' + (i * w + 1).toFixed(1) + '" y="' + (88 - hr).toFixed(1) + '" width="' + (w - 2).toFixed(1) + '" height="' + hr.toFixed(1) + '" fill="var(--pw,#7c4dff)"/>' +
            '<rect x="' + (i * w + 1).toFixed(1) + '" y="' + (88 - hr - ht).toFixed(1) + '" width="' + (w - 2).toFixed(1) + '" height="' + ht.toFixed(1) + '" fill="var(--pw2,#aaa)"/>';
    });
    var nodes = d.nodes || [], nm = 1;
    nodes.forEach(function(n) { var t = (+n[1] || 0) + (+n[2] || 0); if (t > nm) nm = t; });
    var nh = '<div style="margin-top:8px;font-weight:700;font-size:13px">Mengikut node</div>';
    nodes.forEach(function(n) {
        var t = (+n[1] || 0) + (+n[2] || 0);
        nh += '<div class="grnd"><div class="grnm">' + grEsc(n[0]) + '</div><div style="flex:1"><i style="width:' + Math.max(2, t / nm * 100).toFixed(0) + '%"></i></div><div>' + grEsc(fmtB(t)) + '</div></div>';
    });
    grUse.body.innerHTML = '<div class="grsum"><div>Jumlah<b>' + grEsc(fmtB(tr + tt)) + '</b></div><div>Muat turun<b>' + grEsc(fmtB(tr)) + '</b></div><div>Muat naik<b>' + grEsc(fmtB(tt)) + '</b></div></div>' + grSvg(bars) + nh;
    var ts = (d.tunsum || '0|0|0').split('|');
    var th = grPairs(d.tunh).reverse();
    var tmx = 1, red = '', tv = [];
    th.forEach(function(p) { if (p[0] > tmx) tmx = p[0]; });
    var tw = 300 / th.length;
    th.forEach(function(p, i) {
        if (p[1] > 0) red += '<rect x="' + (i * tw).toFixed(1) + '" y="0" width="' + tw.toFixed(1) + '" height="88" fill="#e5484d" opacity=".25"/>';
        tv.push(p[0]);
    });
    grTun.body.innerHTML = '<div class="grsum"><div>Purata<b>' + (+ts[0] || 0) + ' ms</b></div><div>Tertinggi<b>' + (+ts[1] || 0) + ' ms</b></div><div>Semakan gagal<b>' + (+ts[2] || 0) + '</b></div></div>' +
        grSvg(red + grLine(tv, tmx, 'var(--pw,#7c4dff)'));
    var dp = (d.drp || '0|').split('|');
    var dh = grPairs(dp[1]).reverse(), cells = '';
    dh.forEach(function(p) { cells += '<i class="' + (p[0] > 0 ? 'bad' : '') + '"></i>'; });
    grDrp.body.innerHTML = '<div class="grsum"><div>Kiraan<b>' + (+dp[0] || 0) + '</b></div></div><div class="grtl">' + cells + '</div>';
}
function grLoad() {
    fetch('/cgi-bin/vless-graphs?_=' + Date.now()).then(function(r) { return r.text(); }).then(function(t) {
        grD = grParse(t);
        grDraw();
    }).catch(function() {});
}
var stGr = E('div', { 'class': 'stgr', 'style': 'display:none' }, [grSpd.card, grUse.card, grTun.card, grDrp.card]);
var stOv;
var grBtnO = E('button', { 'class': 'on' }, 'Overview');
var grBtnG = E('button', {}, 'Graphs');
function grSet(m) {
    grMode = m;
    grBtnO.className = (m === 'ov') ? 'on' : '';
    grBtnG.className = (m === 'gr') ? 'on' : '';
    stOv.style.display = (m === 'ov') ? '' : 'none';
    stGr.style.display = (m === 'gr') ? '' : 'none';
    if (m === 'gr') grLoad();
}
grBtnO.addEventListener('click', function() { grSet('ov'); });
grBtnG.addEventListener('click', function() { grSet('gr'); });
var grSeg = E('div', { 'class': 'grseg' }, [grBtnO, grBtnG]);
setInterval(function() { if (grMode === 'gr') grLoad(); }, 60000);
var grLv = [], grLp = null;
function grSpdDraw() {
    if (!grLv.length) return;
    var rx = grLv.map(function(a) { return a[0]; }), tx = grLv.map(function(a) { return a[1]; });
    var mx = Math.max.apply(null, rx.concat(tx).concat([0.1]));
    var c = grLv[grLv.length - 1];
    grSpd.body.innerHTML = '<div class="grsum"><div>Download<b>' + c[0].toFixed(2) + ' Mbps</b></div><div>Upload<b>' + c[1].toFixed(2) + ' Mbps</b></div><div>Puncak<b>' + mx.toFixed(2) + '</b></div></div>' +
        grSvg(grLine(rx, mx, 'var(--pw,#7c4dff)') + grLine(tx, mx, 'var(--pw2,#aaa)'));
}
function grTick() {
    if (grMode !== 'gr') { grLp = null; return; }
    fetch('/cgi-bin/vless-session', { cache: 'no-store' }).then(function(r) { return r.text(); }).then(function(t) {
        var p = t.trim().split('|'), rx = +p[1], tx = +p[2], now = Date.now();
        if (grLp && rx >= grLp.rx && tx >= grLp.tx) {
            var dt = (now - grLp.t) / 1000;
            if (dt > 0) {
                grLv.push([(rx - grLp.rx) * 8 / dt / 1e6, (tx - grLp.tx) * 8 / dt / 1e6]);
                if (grLv.length > 90) grLv.shift();
                grSpdDraw();
            }
        }
        grLp = { rx: rx, tx: tx, t: now };
    }).catch(function() {});
}
setInterval(grTick, 2000);


var stOv = E('div', { 'class': 'stov' }, [
            E('div', { 'class': 'sec-title' }, 'Overview'),
            E('div', { 'class': 'stcard' }, [
                stRow('\uD83D\uDEE1', 'Tunnel', stV.tun, E('button', { 'class': 'strf', 'click': stLoad }, '\u21BB')),
                stRow('\uD83D\uDCF6', 'WAN', stV.wan),
                stRow('\uD83D\uDCBB', 'Device', stV.ram),
                stBar
            ]),
            E('div', { 'class': 'sec-title' }, 'Connection'),
            E('div', { 'class': 'stcard' }, [
                stRow('\uD83C\uDF10', 'Public IP', stV.pub),
                stRow('\uD83D\uDCCD', 'Country', stV.cty),
                stRow('\uD83C\uDFE2', 'ISP', stV.isp),
                stRow('\uD83D\uDD12', 'Mode', stV.mode),
                stRow('\u23F1', 'Uptime', stV.up),
                stRow('\u21C5', 'Traffic', stV.trf)
            ]),
            E('div', { 'class': 'sec-title' }, 'Network'),
            E('div', { 'class': 'stcard' }, [
                stRow('\uD83D\uDCE1', 'WAN IP', stV.wip),
                stRow('\u27A4', 'Gateway', stV.gw),
                stRow('\uD83D\uDDC4', 'DNS 1', stV.d1),
                stRow('\uD83D\uDDC4', 'DNS 2', stV.d2),
                stRow('\uD83D\uDCC9', 'WAN drops', stV.drp)
            ])
        ]);
        var stBox = E('div', { 'class': 'stbox' }, [ grSeg, stOv, stGr ]);
        var stTimer = setInterval(function() {
            if (!stBox.isConnected) { if (stBox._seen) clearInterval(stTimer); return; }
            stBox._seen = true;
            if (stBox.offsetParent === null) return;
            if (Date.now() - stLast > 15000) stLoad();
        }, 1000);
        var cards = nodes.map(function(n) {
            var li = latInfo(NS[n.name]);
            var stTxt = n.active ? 'Aktif' : (li.st === 'DOWN' ? 'Down' : 'Hidup');
            var stCls = n.active ? 'b-act' : (li.st === 'DOWN' ? 'b-down' : 'b-ok');
            var more = E('div', { 'class': 'more' }, [
                E('button', { 'click': function() { editNode(n); } }, 'Edit'),
                E('button', { 'class': 'del', 'click': function() {
                    if (!window.confirm('Padam ' + n.name + '?')) return;
                    act(['delete', n.name], 'Memadam...');
                } }, 'Hapus')
            ]);
            var main = n.active
                ? E('button', { 'class': 'stop', 'click': function() { act(['stop'], 'Menghentikan...'); } }, 'Berhenti')
                : E('button', { 'click': function() { act(['switch', n.name], 'Menukar node, sila tunggu...'); } }, 'Aktifkan');
            var row = [ main ];
            if (!n.active) row.push(E('button', { 'class': 'g', 'click': function() { more.classList.toggle('open'); } }, '\u22EF'));
            return E('div', { 'class': 'card' + (n.active ? ' act' : '') }, [
                E('div', { 'class': 'nm' }, n.name),
                E('div', { 'class': 'meta' }, [
                    E('span', { 'class': 'badge ' + stCls }, stTxt),
                    bars(li.lv, li.col),
                    E('span', { 'style': 'color:' + li.col + ';font-weight:bold' }, li.txt + (n.active ? ' (penuh)' : ''))
                ]),
                E('div', { 'class': 'row' }, row),
                more
            ]);
        });

        var linkBox = E('textarea', { 'placeholder': 'Tampal link vless:// di sini...' });
        var addBox = E('details', {}, [
            E('summary', {}, '+ Tambah Node Baharu'),
            E('div', {}, [
                linkBox,
                E('button', { 'class': 'pri', 'click': function() {
                    var l = linkBox.value.trim();
                    if (!l) return;
                    act(['import', l], 'Mengimport...');
                } }, 'IMPORT DATA')
            ])
        ]);

        var wdPre = E('pre', {}, 'Memuatkan...');
        var logBox = E('details', { 'toggle': function() {
            if (!logBox.open) return;
            fetch('/cgi-bin/vless-wd-log', { cache: 'no-store' }).then(function(r) { return r.text(); }).then(function(t) { wdPre.textContent = t; }).catch(function(e) { wdPre.textContent = 'Ralat: ' + e.message; });
        } }, [ E('summary', {}, 'Sejarah Auto Switch'), E('div', {}, [ wdPre ]) ]);
        var usePre = E('pre', {}, 'Memuatkan...');
        function fmtMB(m) { m = parseInt(m, 10) || 0; return m >= 1024 ? (m / 1024).toFixed(2) + ' GB' : m + ' MB'; }
        var useBox = E('details', { 'toggle': function() {
            if (!useBox.open) return;
            fetch('/cgi-bin/vless-usage', { cache: 'no-store' }).then(function(r) { return r.text(); }).then(function(t) {
                var out = [];
                t.split('\n').forEach(function(l) {
                    var p = l.split('|');
                    if (p.length == 3) out.push(p[0] + '\n   Turun: ' + fmtMB(p[1]) + '   Naik: ' + fmtMB(p[2]));
                });
                usePre.textContent = out.length ? out.join('\n') : 'Belum ada data.';
            }).catch(function() { usePre.textContent = 'Ralat memuatkan data.'; });
        } }, [ E('summary', {}, 'Penggunaan Data per Node'), E('div', {}, [ usePre ]) ]);


        
var pre = E('pre', { 'id': 'v3-latency-result' }, 'Tekan butang untuk menguji semua node.');
        var v3Box = E('details', {}, [
            E('summary', {}, 'Modul Tambahan V3'),
            E('div', {}, [
                E('p', {}, 'Ujian sambungan TCP untuk semua node VLESS'),
                E('button', { 'class': 'pri', 'click': function() {
                    pre.textContent = 'Sedang menguji...';
                    fetch('/cgi-bin/vless-v3-control?action=ping').then(function(r) {
                        if (!r.ok) throw new Error('HTTP ' + r.status);
                        return r.text();
                    }).then(function(t) { pre.textContent = t; }).catch(function(e) { pre.textContent = 'Ralat: ' + e.message; });
                } }, 'UJI LATENCY SEMUA NODE'),
                pre
            ])
        ]);

        setTimeout(function() { if (!document.getElementById('v3-monitor-script')) { var s = document.createElement('script'); s.id = 'v3-monitor-script'; s.src = '/luci-static/v3-monitor.js'; document.head.appendChild(s); } }, 400);
        setTimeout(function() { if (!document.getElementById('v3-panel-script')) { var p = document.createElement('script'); p.id = 'v3-panel-script'; p.src = '/luci-static/v3-panel.js'; document.head.appendChild(p); } }, 800);

        return E('div', { 'class': 'v-dash cbi-map v4' }, [
            E('style', {}, CSS),
            hero,
            E('div', { 'class': 'sec-title' }, 'Auto WAN Detection'),
            chips,
            E('div', { 'class': 'sec-title' }, 'Pangkalan Data Node'),
            pickBar,
            E('div', { 'class': 'grid' }, cards),
            addBox,
            logBox,
                        useBox,
            v3Box,
            stBox
        ]);
    },
    handleSaveApply: null, handleSave: null, handleReset: null
});
