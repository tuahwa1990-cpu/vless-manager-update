#!/bin/sh
set -eu

BASE=/etc/vless-manager

# Aktifkan Global Proxy
"$BASE/global-control.sh" on || exit 1

# Tandakan pengaktifan belum disahkan
touch "$BASE/global-pending"

# Pulihkan sambungan asal selepas 90 saat
(
    sleep 90
    if [ -f "$BASE/global-pending" ]; then
        "$BASE/global-control.sh" off
        rm -f "$BASE/global-pending"
        logger -t vless-manager "Automatic rollback executed"
    fi
) </dev/null >/tmp/vless-rollback.log 2>&1 &

echo "GLOBAL PROXY ON - automatic rollback in 90 seconds"
