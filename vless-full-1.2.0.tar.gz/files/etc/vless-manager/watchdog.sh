#!/bin/sh
B=/etc/vless-manager
LOG=$B/watchdog.log
AS=/overlay/vless-manager-pro-v3/config/autoswitch-enabled
PR=/overlay/vless-manager-pro-v3/config/node-priority.txt
C=/tmp/vless-node-probe.cache
EXCLUDE="TESTNODE"
FAILS=0
log() { logger -t VLESS-WD "$1"; echo "$(date '+%F %T') $1" >> $LOG; [ $(wc -l < $LOG) -gt 200 ] && tail -n 100 $LOG > $LOG.tmp && mv $LOG.tmp $LOG; }
check() {
  curl -4 -fsS --connect-timeout 5 --max-time 12 \
    --socks5-hostname 127.0.0.1:10808 \
    https://www.gstatic.com/generate_204 -o /dev/null
}
log "Pemantau bermula (ikut node-priority.txt)"
while true; do
  sleep 30
  pidof sing-box >/dev/null || continue
  [ -f $B/global-enabled ] || continue
  [ -f $AS ] || { FAILS=0; continue; }
  if check; then FAILS=0; continue; fi
  FAILS=$((FAILS+1))
  [ $FAILS -lt 3 ] && continue
  CUR=$(cat $B/active-node 2>/dev/null)
  log "Node $CUR gagal 3 kali, menguji semua node"
  rm -f $C
  sh /usr/libexec/vless-node-probe
  DONE=0
  for N in $(tr -d '\r' < $PR 2>/dev/null); do
    [ "$N" = "$CUR" ] && continue
    case " $EXCLUDE " in *" $N "*) continue;; esac
    grep -q "^$N|OK|" $C 2>/dev/null || continue
    log "Mencuba $N"
    if sh $B/switch-node.sh "$N" | grep -q SUCCESS; then
      log "Bertukar ke $N"
      DONE=1
      break
    fi
  done
  [ $DONE -eq 1 ] || log "Tiada node berfungsi dalam senarai keutamaan"
  FAILS=0
done
