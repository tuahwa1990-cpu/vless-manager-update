let fs = require("fs");
let name = ARGV[0];

if (!name || !match(name, /^[a-zA-Z0-9_-]{1,48}$/))
    die("ERROR: Nama node tidak sah\n");

let source = "/etc/vless-manager/nodes/" + name + ".json";
let content = fs.readfile(source);

if (!content)
    die("ERROR: Node tidak dijumpai\n");

let node = json(content);

node.inbounds = [{
    type: "socks",
    tag: "test-socks",
    listen: "127.0.0.1",
    listen_port: 10810
}];

let output = "/tmp/vless-test-" + name + ".json";

if (!fs.writefile(output, sprintf("%J\n", node)))
    die("ERROR: Gagal menyediakan konfigurasi\n");

print("SUCCESS: ", output, "\n");
