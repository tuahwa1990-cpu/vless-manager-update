import * as fs from 'fs';

let c = json(fs.readfile('/etc/vless-manager/singbox.json'));

if (!c || type(c.outbounds) != 'array')
    die('Invalid sing-box configuration');

let proxy = null;

for (let o in c.outbounds) {
    if (o.type == 'vless') {
        proxy = o.tag;
        break;
    }
}

if (!proxy)
    die('VLESS outbound not found');

if (type(c.inbounds) != 'array')
    c.inbounds = [];

let inbound = [];

for (let i in c.inbounds) {
    if (i.tag != 'vless-global-tproxy')
        push(inbound, i);
}

push(inbound, {
    type: 'tproxy',
    tag: 'vless-global-tproxy',
    listen: '0.0.0.0',
    listen_port: 12345
});

c.inbounds = inbound;

if (!c.route)
    c.route = {};

if (type(c.route.rules) != 'array')
    c.route.rules = [];

c.route.final = proxy;

fs.writefile(
    '/etc/vless-manager/singbox-global.json',
    sprintf('%J\n', c)
);
