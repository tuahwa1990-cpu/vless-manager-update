#!/bin/sh

B=/etc/vless-manager
NAME="$1"
SOURCE="$B/nodes/$NAME.json"
TARGET="$B/singbox.json"
GLOBAL="$B/singbox-global.json"
ACTIVE="$B/active-node"
LOCK=/tmp/vless-switch.lock

case "$NAME" in
  ""|*[!a-zA-Z0-9_-]*) exit 1 ;;
esac

[ -f "$SOURCE" ] || {
  echo "FAIL: Node tidak dijumpai"
  exit 1
}

(
flock -x 9 || exit 1

OLD=$(cat "$ACTIVE" 2>/dev/null)

if [ "$NAME" = "$OLD" ]; then
  if curl -4 -fsS --connect-timeout 5 --max-time 12 \
    --socks5-hostname 127.0.0.1:10808 \
    https://www.gstatic.com/generate_204 \
    -o /dev/null; then
    echo "SUCCESS: Node sudah aktif"
    exit 0
  fi
fi

WORK=$(mktemp -d /tmp/vless-switch.XXXXXX) || exit 1
trap 'rm -rf "$WORK"' EXIT HUP INT TERM

cp -p "$TARGET" "$WORK/original.json" || exit 1
cp -p "$GLOBAL" "$WORK/original-global.json" || exit 1

rollback() {
  echo "ROLLBACK: Memulihkan node $OLD"

  cp -p "$WORK/original.json" "$TARGET"
  cp -p "$WORK/original-global.json" "$GLOBAL"

  /etc/init.d/vless-manager stop >/dev/null 2>&1
  /etc/init.d/vless-manager restart >/dev/null 2>&1

  printf '%s\n' "$OLD" > "$ACTIVE"

  if [ -f "$B/global-enabled" ]; then
    sh "$B/global-control.sh" on >/dev/null 2>&1
  fi
}

cat > "$WORK/build.uc" <<'UC_EOF'
let fs = require('fs');
let f = fs.open(ARGV[0], 'r');
let node = json(f.read('all'));
f.close();

let outbound = node.outbounds[0];
let tag = outbound.tag || "proxy";
outbound.tag = tag;

let config = {
  log: { level: "info", timestamp: true },
  inbounds: [
    {
      type: "socks",
      tag: "socks-in",
      listen: "127.0.0.1",
      listen_port: 10808
    },
    {
      type: "tproxy",
      tag: "vless-global-tproxy",
      listen: "0.0.0.0",
      listen_port: 12345
    }
  ],
  outbounds: [
    outbound,
    { type: "direct", tag: "direct-out" },
    { type: "block", tag: "block-out" }
  ],
  route: {
    rules: [
      { port: 53, outbound: "direct-out" },
      { network: "udp", port: 443, outbound: "block-out" },
      { network: "udp", outbound: "block-out" }
    ],
    final: tag,
    auto_detect_interface: true
  }
};

let o = fs.open(ARGV[1], 'w');
o.write(sprintf("%.J", config));
o.close();
UC_EOF

ucode "$WORK/build.uc" "$SOURCE" "$WORK/new.json" || {
  echo "FAIL: Tidak dapat bina konfigurasi"
  exit 1
}

sing-box check -c "$WORK/new.json" >/dev/null 2>&1 || {
  echo "FAIL: Konfigurasi tidak sah"
  exit 1
}

cp -p "$WORK/new.json" "$TARGET" || {
  rollback
  exit 1
}

cp -p "$WORK/new.json" "$GLOBAL" || {
  rollback
  exit 1
}

/etc/init.d/vless-manager stop >/dev/null 2>&1
/etc/init.d/vless-manager restart >/dev/null 2>&1

sleep 4

if curl -4 -fsS --connect-timeout 8 --max-time 20 \
  --socks5-hostname 127.0.0.1:10808 \
  https://www.gstatic.com/generate_204 \
  -o /dev/null; then

  printf '%s\n' "$NAME" > "$ACTIVE"

  if [ -f "$B/global-enabled" ]; then
    sh "$B/global-control.sh" on >/dev/null 2>&1
  fi

  echo "SUCCESS: $OLD -> $NAME"
  logger -t VLESS-V3 "Node switched: $OLD -> $NAME"
  exit 0
fi

echo "FAIL: Sambungan node baharu gagal"
rollback
exit 1

) 9>"$LOCK"
