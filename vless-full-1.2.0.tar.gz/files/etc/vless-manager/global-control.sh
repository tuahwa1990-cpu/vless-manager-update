#!/bin/sh

BASE=/etc/vless-manager
SERVICE=/etc/init.d/vless-manager
MARK=1
TABLE=100

off() {
    nft delete table inet vlessmgr 2>/dev/null || true
    while ip -4 rule del fwmark "$MARK" table "$TABLE" 2>/dev/null; do :; done
    ip -4 route flush table "$TABLE" 2>/dev/null || true

    if [ -f "$BASE/backup-global/singbox.json" ]; then
        cp "$BASE/backup-global/singbox.json" "$BASE/singbox.json"
        "$SERVICE" restart >/dev/null 2>&1
    fi

    rm -f "$BASE/global-enabled"
    echo "GLOBAL PROXY OFF"
}

on() {
    [ -s "$BASE/singbox-global.json" ] || {
        echo "ERROR: Global configuration missing"
        return 1
    }

    sing-box check -c "$BASE/singbox-global.json" || return 1

    cp "$BASE/singbox-global.json" "$BASE/singbox.json"
    "$SERVICE" restart >/dev/null 2>&1 || {
        off
        return 1
    }

    sleep 2

    "$SERVICE" status >/dev/null 2>&1 || {
        off
        return 1
    }

    ip -4 route replace local 0.0.0.0/0 dev lo table "$TABLE" || {
        off
        return 1
    }

    ip -4 rule add fwmark "$MARK" table "$TABLE" priority 100 2>/dev/null || true

    nft delete table inet vlessmgr 2>/dev/null || true

    nft -f "$BASE/global.nft" || {
        off
        return 1
    }

    touch "$BASE/global-enabled"
    echo "GLOBAL PROXY ON"
}

case "$1" in
    on) on ;;
    off) off ;;
    status)
        if [ -f "$BASE/global-enabled" ]; then
            echo "ON"
        else
            echo "OFF"
        fi
        ;;
    *)
        echo "Usage: $0 on|off|status"
        exit 1
        ;;
esac
