#!/bin/sh
echo "=== NEWIFI D2 VLESS NODE LIST ==="
active="$(cat /etc/vless-manager/active-node 2>/dev/null)"
for file in /etc/vless-manager/nodes/*.json; do
    [ -f "$file" ] || continue
    name="${file##*/}"
    name="${name%.json}"
    if [ "$name" = "$active" ]; then
        echo "[ACTIVE] $name"
    else
        echo "[SAVED]  $name"
    fi
done
