let fs = require("fs");

let name = ARGV[0];
let raw = ARGV[1];

if (!name || !match(name, /^[a-zA-Z0-9_-]{1,48}$/))
    die("ERROR: Nama node tidak sah\n");

let file = "/etc/vless-manager/nodes/" + name + ".json";
let original = fs.readfile(file);

if (original == null)
    die("ERROR: Node tidak dijumpai\n");

let active = trim(fs.readfile("/etc/vless-manager/active-node") || "");

if (name == active)
    die("ERROR: Node aktif tidak boleh diedit\n");

let data = json(raw);
if (!data || type(data) != "object")
    die("ERROR: Data JSON tidak sah\n");

let node = json(original);
let new_name = data.name || name;
if (type(new_name) != "string" || !match(new_name, /^[a-zA-Z0-9_-]{1,48}$/))
    die("ERROR: Nama node baharu tidak sah\n");
if (new_name != name && fs.readfile("/etc/vless-manager/nodes/" + new_name + ".json") != null)
    die("ERROR: Nama node sudah digunakan\n");
let o = node.outbounds[0];

if (!o || o.type != "vless")
    die("ERROR: Bukan konfigurasi VLESS\n");

let server = data.server;
let port = int(data.port);
let uuid = data.uuid;
let host = data.host;
let path = data.path;

if (!server || !match(server, /^[a-zA-Z0-9._-]+$/))
    die("ERROR: Server tidak sah\n");

if (port < 1 || port > 65535)
    die("ERROR: Port tidak sah\n");

if (!uuid || !match(uuid, /^[0-9a-fA-F]{8}(-[0-9a-fA-F]{4}){3}-[0-9a-fA-F]{12}$/))
    die("ERROR: UUID tidak sah\n");

if (type(host) != "string" || (host && !match(host, /^[a-zA-Z0-9._:-]+$/)))
    die("ERROR: WS Host tidak sah\n");

if (type(path) != "string" || !match(path, /^\//))
    die("ERROR: WS Path tidak sah\n");

o.server = server;
o.server_port = port;
o.uuid = uuid;
o.network = "tcp";
o.tls = { enabled: false };
o.transport = {
    type: "ws",
    path: path,
    headers: { Host: host || server }
};

o.tag = new_name;
node.route.final = new_name;
let tmp = "/etc/vless-manager/nodes/." + name + ".edit-tmp";

if (!fs.writefile(tmp, sprintf("%J\n", node)))
    die("ERROR: Gagal menulis fail sementara\n");

let result = system("sing-box check -c " + tmp + " >/dev/null 2>&1");

if (result != 0) {
    fs.unlink(tmp);
    die("ERROR: Konfigurasi sing-box tidak sah\n");
}

let destination = "/etc/vless-manager/nodes/" + new_name + ".json";
if (new_name != name && fs.readfile(destination) != null) {
    fs.unlink(tmp);
    die("ERROR: Nama node sudah digunakan\n");
}
if (!fs.writefile(destination, sprintf("%J\n", node))) {
    fs.unlink(tmp);
    die("ERROR: Gagal menyimpan node\n");
}
system("chmod 600 " + destination);
if (new_name != name) {
    fs.unlink(file);
}
fs.unlink(tmp);
print("SUCCESS: Node berjaya dikemas kini\n");
