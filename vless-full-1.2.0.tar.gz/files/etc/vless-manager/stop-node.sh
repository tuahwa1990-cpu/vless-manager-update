#!/bin/sh

BASE="/etc/vless-manager"
SERVICE="/etc/init.d/vless-manager"

# Hentikan pemintasan Global VLESS
nft delete table inet vlessmgr 2>/dev/null || true

# Buang peraturan routing VLESS sahaja
while ip -4 rule del fwmark 1 table 100 2>/dev/null
do
    :
done

ip -4 route flush table 100 2>/dev/null || true

# Hentikan sing-box melalui procd
"$SERVICE" stop || exit 1

# Sahkan proses sudah berhenti
if pidof sing-box >/dev/null 2>&1; then
    echo "ERROR: sing-box masih berjalan"
    exit 1
fi

# Kemaskini status
rm -f "$BASE/global-enabled"
rm -f "$BASE/active-node"

echo "SUCCESS: VLESS dihentikan. Node disimpan."
