#!/bin/sh
set -eu

BASE=/etc/vless-manager

[ -s "$BASE/singbox.json" ] || {
    echo "ERROR: MEDIAV2 configuration missing"
    exit 1
}

command -v sing-box >/dev/null || exit 1
command -v ucode >/dev/null || exit 1
command -v nft >/dev/null || exit 1
command -v ip >/dev/null || exit 1

cat > "$BASE/build-global.uc" <<'UCODE'
import * as fs from 'fs';

let c = json(fs.readfile('/etc/vless-manager/singbox.json'));

if (!c || type(c.outbounds) != 'array')
    die('Invalid sing-box configuration');

let proxy = null;

for (let o in c.outbounds) {
    if (o.type == 'vless') {
        proxy = o.tag;
        break;
    }
}

if (!proxy)
    die('VLESS outbound not found');

if (type(c.inbounds) != 'array')
    c.inbounds = [];

let inbound = [];

for (let i in c.inbounds) {
    if (i.tag != 'vless-global-tproxy')
        push(inbound, i);
}

push(inbound, {
    type: 'tproxy',
    tag: 'vless-global-tproxy',
    listen: '0.0.0.0',
    listen_port: 12345
});

c.inbounds = inbound;

if (!c.route)
    c.route = {};

if (type(c.route.rules) != 'array')
    c.route.rules = [];

c.route.final = proxy;

fs.writefile(
    '/etc/vless-manager/singbox-global.json',
    sprintf('%J\n', c)
);
UCODE

ucode "$BASE/build-global.uc"

echo "=== VALIDATING GLOBAL CONFIG ==="

if sing-box check -c "$BASE/singbox-global.json"; then
    echo "GLOBAL CONFIG READY"
else
    echo "GLOBAL CONFIG FAILED"
    exit 1
fi
