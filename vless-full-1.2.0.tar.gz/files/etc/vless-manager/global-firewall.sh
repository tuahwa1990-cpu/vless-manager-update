#!/bin/sh
set -eu

BASE=/etc/vless-manager
LAN="$(ubus call network.interface.lan status | jsonfilter -e '@.l3_device')"

[ -n "$LAN" ] || {
    echo "ERROR: LAN interface not found"
    exit 1
}

case "$LAN" in
    *[!a-zA-Z0-9_.:-]*)
        echo "ERROR: Invalid LAN interface"
        exit 1
        ;;
esac

cat > "$BASE/global.nft" <<NFT
add table inet vlessmgr
add chain inet vlessmgr prerouting { type filter hook prerouting priority mangle; policy accept; }
add rule inet vlessmgr prerouting iifname "$LAN" meta nfproto ipv4 fib daddr type local return
add rule inet vlessmgr prerouting iifname "$LAN" meta nfproto ipv4 ip daddr { 0.0.0.0/8, 10.0.0.0/8, 100.64.0.0/10, 127.0.0.0/8, 169.254.0.0/16, 172.16.0.0/12, 192.168.0.0/16, 224.0.0.0/4, 240.0.0.0/4 } return
add rule inet vlessmgr prerouting iifname "$LAN" meta nfproto ipv4 meta l4proto { tcp, udp } tproxy ip to :12345 meta mark set 1 accept
NFT

echo "FIREWALL CONFIG READY"
echo "LAN: $LAN"
echo "Global Proxy: OFF"
