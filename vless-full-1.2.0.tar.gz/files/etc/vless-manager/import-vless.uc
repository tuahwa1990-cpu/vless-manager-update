let fs = require("fs");
function urldecode(s) {
    let out = "";
    let i = 0;
    while (i < length(s)) {
        if (substr(s, i, 1) == "%" && i + 2 < length(s)) {
            let h = substr(s, i + 1, 2);
            if (match(h, /^[0-9A-Fa-f]{2}$/)) {
                out += chr(int(h, 16));
                i += 3;
                continue;
            }
        }
        out += substr(s, i, 1);
        i++;
    }
    return out;
}

let link = ARGV[0];

if (!link || substr(link, 0, 8) != "vless://") {
    die("ERROR: Invalid VLESS link\n");
}

let body = substr(link, 8);
let parts = split(body, "#");
let name = length(parts) > 1 ? urldecode(parts[1]) : "VLESS";
let main = split(parts[0], "?");
let auth = split(main[0], "@");

if (length(auth) != 2) {
    die("ERROR: Invalid VLESS address\n");
}

let uuid = auth[0];
let server = split(auth[1], ":")[0];
let port = int(split(auth[1], ":")[1]);

print("NODE: ", name, "\n");
print("SERVER: ", server, "\n");
print("PORT: ", port, "\n");
print("UUID: ", uuid, "\n");

let params = {};
if (length(main) > 1) {
    for (let item in split(main[1], "&")) {
        let pair = split(item, "=");
        if (length(pair) >= 2)
            params[pair[0]] = urldecode(join("=", slice(pair, 1)));
    }
}

let transport = params.type || "tcp";
let ws_host = params.host || "";
let ws_path = params.path || "/";
let security = params.security || "none";

print("TRANSPORT: ", transport, "\n");
print("WS HOST: ", ws_host, "\n");
print("WS PATH: ", ws_path, "\n");
print("SECURITY: ", security, "\n");

if (!match(uuid, /^[0-9a-fA-F]{8}(-[0-9a-fA-F]{4}){3}-[0-9a-fA-F]{12}$/))
    die("ERROR: UUID tidak sah\n");

if (!match(server, /^[a-zA-Z0-9._-]+$/) || port < 1 || port > 65535)
    die("ERROR: Server atau port tidak sah\n");

if (transport != "ws" || security != "none")
    die("ERROR: Hanya VLESS WS tanpa TLS disokong\n");

if (ws_host && !match(ws_host, /^[a-zA-Z0-9._:-]+$/))
    die("ERROR: WS Host tidak sah\n");

let safe_name = replace(name, /[^a-zA-Z0-9_-]/g, "_");
if (!safe_name || length(safe_name) > 48)
    die("ERROR: Nama node tidak sah atau terlalu panjang\n");

let output = "/etc/vless-manager/nodes/" + safe_name + ".json";

let n = 2;
while (fs.readfile(output) != null) {
    safe_name = replace(name, /[^a-zA-Z0-9_-]/g, "_");
    safe_name = substr(safe_name, 0, 48 - length(sprintf("_%d", n))) + sprintf("_%d", n);
    output = "/etc/vless-manager/nodes/" + safe_name + ".json";
    n++;
}

let node = {
    log: { level: "info", timestamp: true },
    inbounds: [{
        type: "socks",
        tag: "socks-in",
        listen: "127.0.0.1",
        listen_port: 10808
    }],
    outbounds: [{
        type: "vless",
        tag: safe_name,
        server: server,
        server_port: port,
        uuid: uuid,
        network: "tcp",
        tls: { enabled: false },
        transport: {
            type: "ws",
            path: ws_path,
            headers: { Host: ws_host || server }
        }
    }],
    route: { final: safe_name }
};

let tmp = "/etc/vless-manager/import-check.json";

if (!fs.writefile(tmp, sprintf("%J\n", node)))
    die("ERROR: Gagal menulis konfigurasi sementara\n");

let result = system("sing-box check -c " + tmp + " >/dev/null 2>&1");

if (result != 0) {
    fs.unlink(tmp);
    die("ERROR: Konfigurasi sing-box tidak sah\n");
}

if (!fs.writefile(output, sprintf("%J\n", node))) {
    fs.unlink(tmp);
    die("ERROR: Gagal menyimpan node\n");
}

fs.unlink(tmp);
print("SUCCESS: Node disimpan sebagai ", safe_name, "\n");
