function urldecode(s) {
    let out = "";
    let i = 0;
    while (i < length(s)) {
        if (substr(s, i, 1) == "%" && i + 2 < length(s)) {
            let h = substr(s, i + 1, 2);
            if (match(h, /^[0-9A-Fa-f]{2}$/)) {
                out += chr(int(h, 16));
                i += 3;
                continue;
            }
        }
        out += substr(s, i, 1);
        i++;
    }
    return out;
}
