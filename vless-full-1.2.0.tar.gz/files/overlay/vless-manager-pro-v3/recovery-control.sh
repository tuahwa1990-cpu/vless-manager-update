#!/bin/sh
D=/overlay/vless-manager-pro-v3
case "$1" in
  on)
    touch "$D/config/recovery-enabled"
    echo "AUTO RECOVERY: ON"
    ;;
  off)
    rm -f "$D/config/recovery-enabled"
    echo "AUTO RECOVERY: OFF"
    ;;
  status)
    if [ -f "$D/config/recovery-enabled" ]; then
      echo "AUTO RECOVERY: ON"
    else
      echo "AUTO RECOVERY: OFF"
    fi
    ;;
  *)
    echo "Gunakan: on | off | status"
    ;;
esac
