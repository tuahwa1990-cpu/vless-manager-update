#!/bin/sh

D=/overlay/vless-manager-pro-v3
B=/etc/vless-manager
C="$D/config"

[ -f "$C/autoswitch-enabled" ] || exit 0
[ -f "$C/failover-approved" ] || exit 0
[ -f "$B/global-enabled" ] || exit 0

"$D/cooldown-control.sh" check || exit 0

ORIGINAL=$(cat "$B/active-node" 2>/dev/null)

# Uji calon sebelum menyentuh Sing-box utama
NEXT=$("$D/find-working-node.sh")

[ -n "$NEXT" ] || {
  logger -t VLESS-V3 "Tiada calon lulus ujian"
  exit 1
}

[ "$NEXT" = "$ORIGINAL" ] && exit 0

# Pastikan Auto Switch masih dibenarkan
[ -f "$C/autoswitch-enabled" ] || exit 0
[ -f "$C/failover-approved" ] || exit 0

logger -t VLESS-V3 "Pertukaran $ORIGINAL ke $NEXT"

"$D/cooldown-control.sh" mark

if "$B/switch-node.sh" "$NEXT"; then
  logger -t VLESS-V3 "Failover berjaya: $NEXT"
  exit 0
fi

logger -t VLESS-V3 "Pertukaran gagal; semak rollback"
exit 1
