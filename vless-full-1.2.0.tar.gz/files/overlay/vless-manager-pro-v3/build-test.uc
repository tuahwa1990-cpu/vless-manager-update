let fs = require('fs');

let f = fs.open(ARGV[0], 'r');
let node = json(f.read('all'));
f.close();

let outbound = node.outbounds[0];
let tag = outbound.tag || 'test-proxy';
outbound.tag = tag;

let config = {
  log: { level: 'warn' },
  inbounds: [{
    type: 'socks',
    tag: 'test-socks',
    listen: '127.0.0.1',
    listen_port: 10809
  }],
  outbounds: [
    outbound,
    { type: 'direct', tag: 'direct-out' }
  ],
  route: {
    final: tag,
    auto_detect_interface: true
  }
};

let out = fs.open(ARGV[1], 'w');
out.write(sprintf('%.J', config));
out.close();
