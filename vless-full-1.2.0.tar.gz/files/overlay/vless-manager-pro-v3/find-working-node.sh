#!/bin/sh

D=/overlay/vless-manager-pro-v3

[ -f "$D/config/autoswitch-enabled" ] || exit 2
[ -f "$D/config/failover-approved" ] || exit 2

"$D/failover-candidates.sh" | while IFS= read -r N
do
    [ -f "$D/config/autoswitch-enabled" ] || exit 2

    if "$D/test-candidate.sh" "$N" >/dev/null 2>&1; then
        printf '%s\n' "$N"
        exit 0
    fi
done
