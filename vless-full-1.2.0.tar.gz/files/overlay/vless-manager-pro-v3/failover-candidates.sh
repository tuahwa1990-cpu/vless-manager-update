#!/bin/sh

B=/etc/vless-manager
P=/overlay/vless-manager-pro-v3/config/node-priority.txt

[ -f "$P" ] || exit 1

ACTIVE=$(cat "$B/active-node" 2>/dev/null)

while IFS= read -r N || [ -n "$N" ]; do
    case "$N" in
        ''|*[!a-zA-Z0-9_-]*) continue ;;
    esac

    [ "$N" = "$ACTIVE" ] && continue
    [ -f "$B/nodes/$N.json" ] || continue

    printf '%s\n' "$N"
done < "$P"
