#!/bin/sh
D=/overlay/vless-manager-pro-v3

[ -f "$D/config/recovery-enabled" ] || exit 0

# Semak Sing-box sahaja; jangan ganggu jika aktif
if pidof sing-box >/dev/null 2>&1; then
    exit 0
fi

logger -t VLESS-V3 "Sing-box tidak aktif; Auto Recovery mencuba pemulihan"

/etc/init.d/vless-manager start
