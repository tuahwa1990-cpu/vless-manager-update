#!/bin/sh

D=/overlay/vless-manager-pro-v3
B=/etc/vless-manager
N="$1"

case "$N" in
  ""|*[!a-zA-Z0-9_.-]*|.|..) exit 1 ;;
esac

[ -f "$B/nodes/$N.json" ] || exit 1

mkdir -p "$D/runtime"

(
flock -n 8 || exit 1

F="$D/runtime/test-node.json"
LOG="$D/runtime/test.log"
PID=""

cleanup() {
  trap - EXIT HUP INT TERM
  if [ -n "$PID" ]; then
    kill "$PID" 2>/dev/null
    wait "$PID" 2>/dev/null
  fi
  rm -f "$F"
}

trap 'cleanup' EXIT
trap 'exit 1' HUP INT TERM

# Jangan ganggu proses lain pada port ujian
if netstat -tln 2>/dev/null | grep -q ':10809 '; then
  exit 1
fi

ucode "$D/build-test.uc" "$B/nodes/$N.json" "$F" || exit 1
sing-box check -c "$F" >/dev/null 2>&1 || exit 1

sing-box run -c "$F" > "$LOG" 2>&1 &
PID=$!

sleep 2

kill -0 "$PID" 2>/dev/null || exit 1

# Cuba dua endpoint berbeza
for URL in \
  https://www.google.com/generate_204 \
  https://cp.cloudflare.com/generate_204
do
  CODE=$(curl -4 -sS -L \
    --connect-timeout 12 --max-time 30 \
    --socks5-hostname 127.0.0.1:10809 \
    -o /dev/null -w '%{http_code}' "$URL" 2>/dev/null)

  case "$CODE" in
    [1-5]??)
      echo "PASS: $N"
      exit 0
      ;;
  esac
done

echo "FAIL: $N"
exit 1

) 8>"$D/runtime/test-candidate.lock"
