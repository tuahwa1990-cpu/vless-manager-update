#!/bin/sh

D=/overlay/vless-manager-pro-v3
F="$D/runtime/last-switch"
COOLDOWN=300

case "$1" in
  check)
    NOW=$(date +%s)
    LAST=$(cat "$F" 2>/dev/null)
    case "$LAST" in
      ''|*[!0-9]*) LAST=0 ;;
    esac

    DIFF=$((NOW - LAST))
    [ "$DIFF" -ge "$COOLDOWN" ]
    ;;
  mark)
    date +%s > "$F"
    ;;
  *)
    echo "Penggunaan: $0 check|mark"
    exit 1
    ;;
esac
