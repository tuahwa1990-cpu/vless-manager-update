#!/bin/sh

D=/overlay/vless-manager-pro-v3
B=/etc/vless-manager
P="$D/config/node-priority.txt"

[ -f "$P" ] || exit 1

ACTIVE=$(cat "$B/active-node" 2>/dev/null)

while IFS= read -r N; do
    case "$N" in
        ''|*[!a-zA-Z0-9_-]*) continue ;;
    esac

    [ "$N" = "$ACTIVE" ] && continue
    [ -f "$B/nodes/$N.json" ] || continue

    echo "$N"
    exit 0
done < "$P"

echo "TIADA NODE SANDARAN"
exit 1
