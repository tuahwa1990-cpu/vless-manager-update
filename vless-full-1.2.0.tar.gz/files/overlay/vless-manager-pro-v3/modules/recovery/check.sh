#!/bin/sh

BASE=/etc/vless-manager
STATE=/overlay/vless-manager-pro-v3
LOCK=/tmp/vless-v3-recovery.lock

[ -f "$STATE/recovery-enabled" ] || exit 0
[ -f "$BASE/global-enabled" ] || exit 0

(
flock -n 9 || exit 0

if curl -4 -fsS --max-time 8 \
    --socks5 127.0.0.1:10808 \
    https://api.ipify.org >/dev/null 2>&1
then
    echo 0 > "$STATE/recovery-failures"
    exit 0
fi

N=$(cat "$STATE/recovery-failures" 2>/dev/null || echo 0)
case "$N" in *[!0-9]*|'') N=0;; esac
N=$((N+1))
echo "$N" > "$STATE/recovery-failures"

[ "$N" -ge 3 ] || exit 0

echo 0 > "$STATE/recovery-failures"

logger -t VLESS-V3 "Recovery: 3 failures detected"

/etc/init.d/vless-manager restart

) 9>"$LOCK"
