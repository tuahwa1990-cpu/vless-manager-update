#!/bin/sh
set -eu

ROOT=/overlay/vless-manager-pro-v3
DEST="$ROOT/backups"
mkdir -p "$DEST"
chmod 700 "$DEST"

DATE=$(date +%Y%m%d-%H%M%S)
FILE="$DEST/vless-backup-$DATE.tar.gz"

tar -czf "$FILE" \
    -C /etc vless-manager \
    -C /etc/init.d vless-manager

chmod 600 "$FILE"

echo "BACKUP: $FILE"
