#!/bin/sh

NODEDIR=/etc/vless-manager/nodes

echo "=== V3 NODE LATENCY TEST ==="

for F in "$NODEDIR"/*.json
do
    [ -f "$F" ] || continue

    NAME=${F##*/}
    NAME=${NAME%.json}

    SERVER=$(jsonfilter -i "$F" -e '@.server' 2>/dev/null || true)
    PORT=$(jsonfilter -i "$F" -e '@.server_port' 2>/dev/null || true)

    if [ -z "$SERVER" ] || [ -z "$PORT" ]; then
        SERVER=$(jsonfilter -i "$F" -e '@.outbounds[0].server' 2>/dev/null || true)
        PORT=$(jsonfilter -i "$F" -e '@.outbounds[0].server_port' 2>/dev/null || true)
    fi

    if [ -z "$SERVER" ] || [ -z "$PORT" ]; then
        echo "$NAME : SKIP (server/port tidak ditemui)"
        continue
    fi

    RESULT=$(curl -s -o /dev/null \
        --connect-timeout 3 --max-time 4 \
        -w '%{time_connect}' \
        "http://$SERVER:$PORT/" 2>/dev/null || true)

    if [ -n "$RESULT" ] && [ "$RESULT" != "0.000000" ]; then
        MS=$(awk "BEGIN {printf \"%.0f\", $RESULT * 1000}")
        echo "$NAME : ${MS} ms (TCP)"
    else
        echo "$NAME : TIMEOUT"
    fi
done

echo "=== LATENCY TEST SELESAI ==="
