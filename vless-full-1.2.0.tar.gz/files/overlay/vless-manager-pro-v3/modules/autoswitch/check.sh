#!/bin/sh

STATE=/overlay/vless-manager-pro-v3
VLESS=/etc/vless-manager

[ -f "$STATE/autoswitch-enabled" ] || exit 0
[ -f "$VLESS/global-enabled" ] || exit 0

ACTIVE=$(cat "$VLESS/active-node" 2>/dev/null)

for F in "$VLESS"/nodes/*.json
do
    [ -f "$F" ] || continue

    NAME=${F##*/}
    NAME=${NAME%.json}

    [ "$NAME" = "$ACTIVE" ] && continue

    case "$NAME" in *[!a-zA-Z0-9_-]*|'') continue;; esac

    logger -t VLESS-V3 "Auto Switch candidate: $NAME"

    # Belum menukar node sehingga polisi failover disahkan
    break
done
