#!/bin/sh

D=/overlay/vless-manager-pro-v3
[ -f "$D/config/autoswitch-enabled" ] || exit 0
[ -f "$D/config/failover-approved" ] || exit 0
C="$D/config"
R="$D/runtime"
LOCK="$R/autoswitch.lock"
FAIL="$R/autoswitch-fails"

[ -f "$C/autoswitch-enabled" ] || exit 0
[ -f /etc/vless-manager/global-enabled ] || exit 0

mkdir -p "$R"

(
flock -n 9 || exit 0

if curl -4 -fsS --max-time 12 \
  --socks5-hostname 127.0.0.1:10808 \
  https://www.gstatic.com/generate_204 \
  -o /dev/null; then

  echo 0 > "$FAIL"
  exit 0
fi

N=$(cat "$FAIL" 2>/dev/null)
case "$N" in
  ''|*[!0-9]*) N=0 ;;
esac

N=$((N + 1))
echo "$N" > "$FAIL"

logger -t VLESS-V3 "Auto Switch: ujian gagal $N/3"

if [ "$N" -ge 3 ]; then
  if "$D/cooldown-control.sh" check; then
    logger -t VLESS-V3 "3 kegagalan dikesan; failover masih dikunci"
        [ -f "$C/failover-approved" ] && /bin/sh "$D/failover-run.sh"
  else
    logger -t VLESS-V3 "Cooldown aktif; pertukaran ditangguhkan"
  fi
  echo 0 > "$FAIL"
fi

) 9>"$LOCK"
