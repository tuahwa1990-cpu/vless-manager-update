#!/bin/sh
D=/overlay/vless-manager-pro-v3
C="$D/config"
BASE=/etc/vless-manager
P="$C/node-priority.txt"

[ -f "$P" ] || exit 1

cp -p "$P" "$P.bak"
TMP="$P.tmp.$$"
cp "$P" "$TMP" || exit 1

ACTIVE=$(cat "$BASE/active-node" 2>/dev/null)

for F in "$BASE"/nodes/*.json; do
    [ -f "$F" ] || continue
    N=${F##*/}
    N=${N%.json}

    case "$N" in
        ''|*[!a-zA-Z0-9_-]*) continue ;;
    esac

    [ "$N" = "$ACTIVE" ] && continue

    grep -Fxq "$N" "$TMP" && continue

    echo "$N" >> "$TMP"
    logger -t VLESS-V3 "Node baharu dikesan: $N"
done

mv "$TMP" "$P"
chmod 600 "$P"
